<?php /* Template Name: Ai-Atlas */ get_header(); ?>


<section class="bannerInnerSection atlasBannerSec">
    <div class="wrapper">
        <?php if( have_rows('banner_section') ): ?>
            <?php while( have_rows('banner_section') ): the_row(); ?>
                <div class="bannerContent">
                    <div class="bannerHeading">
                        <h4 class="manrope"><?php echo get_sub_field('sub_heading'); ?></h4>
                        <h1 class="manrope"><?php echo get_sub_field('heading'); ?></h1>
                        <p><?php echo get_sub_field('description'); ?></p>
                    </div>
                    <?php $bannerimage = get_sub_field('banner_image'); if( !empty( $bannerimage ) ): ?>
                        <img src="<?php echo esc_url($bannerimage['url']); ?>" loading="lazy" alt="<?php echo esc_attr($bannerimage['alt']); ?>" />
                    <?php endif; ?>
                </div>
                <div class="casestudyCTA">
                    <a href="<?php echo get_sub_field('cta_link'); ?>" class="teritaryCTA"><?php echo get_sub_field('cta_text'); ?>
                        <span>
                            <svg width="19" height="19" viewBox="0 0 19 19" fill="none" xmlns="http://www.w3.org/2000/svg">
                                <path d="M2.35288 9.41198C2.35288 9.56799 2.41486 9.71761 2.52517 9.82792C2.63549 9.93824 2.78511 10.0002 2.94112 10.0002H14.4624L10.172 14.2899C10.1173 14.3446 10.074 14.4095 10.0444 14.4809C10.0148 14.5523 9.99961 14.6288 9.99961 14.7061C9.99961 14.7834 10.0148 14.8599 10.0444 14.9313C10.074 15.0027 10.1173 15.0676 10.172 15.1223C10.2267 15.1769 10.2915 15.2203 10.3629 15.2499C10.4343 15.2794 10.5109 15.2947 10.5882 15.2947C10.6655 15.2947 10.742 15.2794 10.8134 15.2499C10.8848 15.2203 10.9497 15.1769 11.0044 15.1223L16.2985 9.82815C16.3532 9.77352 16.3965 9.70865 16.4262 9.63724C16.4558 9.56582 16.471 9.48928 16.471 9.41198C16.471 9.33467 16.4558 9.25813 16.4262 9.18672C16.3965 9.11531 16.3532 9.05043 16.2985 8.9958L11.0044 3.70168C10.894 3.59131 10.7443 3.5293 10.5882 3.5293C10.4321 3.5293 10.2824 3.59131 10.172 3.70168C10.0616 3.81206 9.99961 3.96176 9.99961 4.11786C9.99961 4.27396 10.0616 4.42366 10.172 4.53404L14.4624 8.82374H2.94112C2.78511 8.82374 2.63549 8.88572 2.52517 8.99603C2.41486 9.10635 2.35288 9.25597 2.35288 9.41198Z" fill="white"/>
                            </svg>
                        </span>
                    </a>
                </div>
            <?php endwhile; ?>
        <?php endif; ?>
    </div>
    <div class="bannerBG">
        <svg xmlns="http://www.w3.org/2000/svg" width="2168" height="658" viewBox="0 0 2168 658" fill="none">
            <g filter="url(#filter0_f_952_6788)">
                <path d="M1891.15 658C1891.15 517.314 1806.12 382.39 1654.74 282.91C1503.37 183.43 1298.07 127.542 1084 127.542C869.929 127.542 664.626 183.43 513.255 282.91C361.885 382.39 276.845 517.314 276.845 658L1891.15 658Z" fill="url(#paint0_linear_952_6788)" fill-opacity="0.984314"/>
            </g>
            <defs>
                <filter id="filter0_f_952_6788" x="-123.155" y="-272.458" width="2414.31" height="1330.46" filterUnits="userSpaceOnUse" color-interpolation-filters="sRGB">
                    <feFlood flood-opacity="0" result="BackgroundImageFix"/>
                    <feBlend mode="normal" in="SourceGraphic" in2="BackgroundImageFix" result="shape"/>
                    <feGaussianBlur stdDeviation="200" result="effect1_foregroundBlur_952_6788"/>
                </filter>
                <linearGradient id="paint0_linear_952_6788" x1="1084" y1="658" x2="1109.13" y2="-74.7586" gradientUnits="userSpaceOnUse">
                    <stop stop-color="#01D3C7"/>
                    <stop offset="0.151345" stop-color="#08A8A2" stop-opacity="0.57"/>
                    <stop offset="0.237738" stop-color="#0B908E" stop-opacity="0.49"/>
                    <stop offset="0.320429" stop-color="#0F797A" stop-opacity="0.34"/>
                    <stop offset="0.43204" stop-color="#14595F" stop-opacity="0.28"/>
                    <stop offset="0.740931" stop-color="#210214" stop-opacity="0"/>
                    <stop offset="1" stop-color="#210214"/>
                </linearGradient>
            </defs>
        </svg>
    </div>
</section>

<section class="solutionSection fourArtifactsSec">
    <div class="secWrapper">
        <?php if( have_rows('four_artifacts') ): ?>
            <?php while( have_rows('four_artifacts') ): the_row(); ?>
                <div class="secHeading">
                    <h2 class="manrope"><?php echo get_sub_field('heading'); ?></h2>
                    <p><?php echo get_sub_field('description'); ?></p>
                </div>
                <div class="cardContainer">
                    <?php if( have_rows('four_artifacts_content') ): ?>
                        <?php $counter=1; while( have_rows('four_artifacts_content') ): the_row(); ?>
                            <div class="solutionCard">
                                <div class="imgBox">
                                    <?php $faimg = get_sub_field('card_image'); if( !empty( $faimg ) ): ?>
                                        <img src="<?php echo esc_url($faimg['url']); ?>" loading="lazy" alt="<?php echo esc_attr($faimg['alt']); ?>" />
                                    <?php endif; ?>
                                </div>
                                <div class="bottomContent">
                                    <span class="manrope num">0<?php echo $counter; ?> </span>
                                    <h3 class="manrope"><?php echo get_sub_field('card_heading'); ?></h3>
                                    <div class="description">
                                        <div class="descriptionInner">
                                            <p><?php echo get_sub_field('card_description'); ?></p>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        <?php $counter=$counter+1; endwhile; ?>
                    <?php endif; ?>
                </div>
            <?php endwhile; ?>
        <?php endif; ?>
    </div>
    <div class="fourArtifactsBG">
        <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 2168 658" fill="none">
            <g filter="url(#filter0_f_952_6788)">
                <path d="M1891.15 658C1891.15 517.314 1806.12 382.39 1654.74 282.91C1503.37 183.43 1298.07 127.542 1084 127.542C869.929 127.542 664.626 183.43 513.255 282.91C361.885 382.39 276.845 517.314 276.845 658L1891.15 658Z" fill="url(#paint0_linear_952_6788)" fill-opacity="0.984314"/>
            </g>
            <defs>
                <filter id="filter0_f_952_6788" x="-123.155" y="-272.458" width="2414.31" height="1330.46" filterUnits="userSpaceOnUse" color-interpolation-filters="sRGB">
                    <feFlood flood-opacity="0" result="BackgroundImageFix"/>
                    <feBlend mode="normal" in="SourceGraphic" in2="BackgroundImageFix" result="shape"/>
                    <feGaussianBlur stdDeviation="200" result="effect1_foregroundBlur_952_6788"/>
                </filter>
                <linearGradient id="paint0_linear_952_6788" x1="1084" y1="658" x2="1109.13" y2="-74.7586" gradientUnits="userSpaceOnUse">
                    <stop stop-color="#01D3C7"/>
                    <stop offset="0.151345" stop-color="#08A8A2" stop-opacity="0.57"/>
                    <stop offset="0.237738" stop-color="#0B908E" stop-opacity="0.49"/>
                    <stop offset="0.320429" stop-color="#0F797A" stop-opacity="0.34"/>
                    <stop offset="0.43204" stop-color="#14595F" stop-opacity="0.28"/>
                    <stop offset="0.740931" stop-color="#210214" stop-opacity="0"/>
                    <stop offset="1" stop-color="#210214"/>
                </linearGradient>
            </defs>
        </svg>
    </div>
</section>

<section class="agentSection">
    <div class="wrapper">
        <?php if( have_rows('studio_agent') ): ?>
            <?php while( have_rows('studio_agent') ): the_row(); ?>
                <div class="mainContainer">
                    <div class="imgBoxes">
                        <?php if( have_rows('studio_agent_content') ): ?>
                            <?php while( have_rows('studio_agent_content') ): the_row(); ?>
                                <?php $studioimg = get_sub_field('card_image'); if( !empty( $studioimg ) ): ?>
                                    <img src="<?php echo esc_url($studioimg['url']); ?>" loading="lazy" alt="<?php echo esc_attr($studioimg['alt']); ?>" />
                                <?php endif; ?>
                            <?php endwhile; ?>
                        <?php endif; ?>
                    </div>
                    <div class="textBoxes">
                        <h3 class="manrope"><?php echo get_sub_field('heading'); ?></h3>
                        <div class="texBoxtSlider">
                            <?php if( have_rows('studio_agent_content') ): ?>
                                <?php while( have_rows('studio_agent_content') ): the_row(); ?>
                                    <div class="box">
                                        <h2 class="manrope"><?php echo get_sub_field('card_heading'); ?></h2>
                                        <p><?php echo get_sub_field('card_description'); ?></p>
                                    </div>
                                <?php endwhile; ?>
                            <?php endif; ?>
                        </div>
                        <div class="arrowBox">
                            <span class="studioPrevArrow">
                                <svg xmlns="http://www.w3.org/2000/svg" width="26" height="22" viewBox="0 0 26 22" fill="none">
                                    <path d="M9.90509 20.9813L0.305793 11.382C0.109955 11.1861 -6.67789e-05 10.9205 -6.81276e-05 10.6436C-6.67789e-05 10.3666 0.109955 10.101 0.305793 9.90515L9.90509 0.305849C10.1009 0.110011 10.3665 -1.03086e-05 10.6435 -1.0983e-05C10.9205 -1.014e-05 11.1861 0.11001 11.3819 0.305848C11.5777 0.501686 11.6878 0.7673 11.6878 1.04426C11.6878 1.32121 11.5777 1.58683 11.3819 1.78266L3.56494 9.59963L24.6732 9.59871C24.9504 9.59871 25.2161 9.70879 25.4121 9.90474C25.608 10.1007 25.7181 10.3664 25.7181 10.6436C25.7181 10.9207 25.608 11.1864 25.4121 11.3824C25.2161 11.5783 24.9504 11.6884 24.6732 11.6884L3.56494 11.6875L11.3819 19.5044C11.5777 19.7003 11.6878 19.9659 11.6878 20.2429C11.6878 20.5198 11.5777 20.7854 11.3819 20.9813C11.1861 21.1771 10.9205 21.2871 10.6435 21.2871C10.3665 21.2871 10.1009 21.1771 9.90509 20.9813Z" fill="#FFF"/>
                                </svg>
                            </span>
                            <span class="studioNextArrow">
                                <svg xmlns="http://www.w3.org/2000/svg" width="26" height="22" viewBox="0 0 26 22" fill="none">
                                    <path d="M15.8129 20.9813L25.4122 11.382C25.6081 11.1861 25.7181 10.9205 25.7181 10.6436C25.7181 10.3666 25.6081 10.101 25.4122 9.90515L15.8129 0.305849C15.6171 0.110011 15.3515 -1.03086e-05 15.0745 -1.0983e-05C14.7976 -1.014e-05 14.5319 0.11001 14.3361 0.305848C14.1403 0.501686 14.0303 0.7673 14.0303 1.04426C14.0303 1.32121 14.1403 1.58683 14.3361 1.78266L22.1531 9.59963L1.04478 9.59871C0.767665 9.59871 0.501903 9.70879 0.305957 9.90474C0.11001 10.1007 -7.1796e-05 10.3664 -7.17854e-05 10.6436C-7.1796e-05 10.9207 0.11001 11.1864 0.305957 11.3824C0.501903 11.5783 0.767665 11.6884 1.04478 11.6884L22.1531 11.6875L14.3361 19.5044C14.1403 19.7003 14.0303 19.9659 14.0303 20.2429C14.0303 20.5198 14.1403 20.7854 14.3361 20.9813C14.5319 21.1771 14.7976 21.2871 15.0745 21.2871C15.3515 21.2871 15.6171 21.1771 15.8129 20.9813Z" fill="#FFF"/>
                                </svg>
                            </span>
                        </div>
                    </div>
                </div>
            <?php endwhile; ?>
        <?php endif; ?>
    </div>
    <div class="agentSecBg">
        <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 2168 658" fill="none">
            <g filter="url(#filter0_f_952_6788)">
                <path d="M1891.15 658C1891.15 517.314 1806.12 382.39 1654.74 282.91C1503.37 183.43 1298.07 127.542 1084 127.542C869.929 127.542 664.626 183.43 513.255 282.91C361.885 382.39 276.845 517.314 276.845 658L1891.15 658Z" fill="url(#paint0_linear_952_6788)" fill-opacity="0.984314"/>
            </g>
            <defs>
                <filter id="filter0_f_952_6788" x="-123.155" y="-272.458" width="2414.31" height="1330.46" filterUnits="userSpaceOnUse" color-interpolation-filters="sRGB">
                    <feFlood flood-opacity="0" result="BackgroundImageFix"/>
                    <feBlend mode="normal" in="SourceGraphic" in2="BackgroundImageFix" result="shape"/>
                    <feGaussianBlur stdDeviation="200" result="effect1_foregroundBlur_952_6788"/>
                </filter>
                <linearGradient id="paint0_linear_952_6788" x1="1084" y1="658" x2="1109.13" y2="-74.7586" gradientUnits="userSpaceOnUse">
                    <stop stop-color="#01D3C7"/>
                    <stop offset="0.151345" stop-color="#08A8A2" stop-opacity="0.57"/>
                    <stop offset="0.237738" stop-color="#0B908E" stop-opacity="0.49"/>
                    <stop offset="0.320429" stop-color="#0F797A" stop-opacity="0.34"/>
                    <stop offset="0.43204" stop-color="#14595F" stop-opacity="0.28"/>
                    <stop offset="0.740931" stop-color="#210214" stop-opacity="0"/>
                    <stop offset="1" stop-color="#210214"/>
                </linearGradient>
            </defs>
        </svg>
    </div>
</section>

<section class="resultSection platformResultSec impactStoriesSec">
    <div class="secWrapper">
        <?php if( have_rows('impact_stories') ): ?>
            <?php while( have_rows('impact_stories') ): the_row(); ?>
                <div class="secHeading ">
                    <div class="headingGroup">
                        <h2 class="manrope"><?php echo get_sub_field('heading'); ?></h2>
                    </div>
                </div>
                <div class="resultsCardLayout">
                    <div class="resultCardSlider platformResultSlider">
                        <?php if( have_rows('impact_stories_content') ): ?>
                            <?php while( have_rows('impact_stories_content') ): the_row(); ?>
                                <a href="<?php echo get_sub_field('card_link'); ?>">
                                    <div class="box">
                                        <span class="tag manrope"><?php echo get_sub_field('card_tag'); ?></span>
                                        <div class="bottomContent">
                                            <h3 class="manrope"><?php echo get_sub_field('card_heading'); ?></h3>
                                        </div>
                                    </div>
                                </a>
                            <?php endwhile; ?>
                        <?php endif; ?>
                    </div>
                    <div class="arrowBox">
                        <span class="platformResultPrevArrow ">
                            <svg xmlns="http://www.w3.org/2000/svg" width="26" height="22" viewBox="0 0 26 22" fill="none">
                                <path d="M9.90509 20.9813L0.305793 11.382C0.109955 11.1861 -6.67789e-05 10.9205 -6.81276e-05 10.6436C-6.67789e-05 10.3666 0.109955 10.101 0.305793 9.90515L9.90509 0.305849C10.1009 0.110011 10.3665 -1.03086e-05 10.6435 -1.0983e-05C10.9205 -1.014e-05 11.1861 0.11001 11.3819 0.305848C11.5777 0.501686 11.6878 0.7673 11.6878 1.04426C11.6878 1.32121 11.5777 1.58683 11.3819 1.78266L3.56494 9.59963L24.6732 9.59871C24.9504 9.59871 25.2161 9.70879 25.4121 9.90474C25.608 10.1007 25.7181 10.3664 25.7181 10.6436C25.7181 10.9207 25.608 11.1864 25.4121 11.3824C25.2161 11.5783 24.9504 11.6884 24.6732 11.6884L3.56494 11.6875L11.3819 19.5044C11.5777 19.7003 11.6878 19.9659 11.6878 20.2429C11.6878 20.5198 11.5777 20.7854 11.3819 20.9813C11.1861 21.1771 10.9205 21.2871 10.6435 21.2871C10.3665 21.2871 10.1009 21.1771 9.90509 20.9813Z" fill="#19060F"/>
                            </svg>
                        </span>
                        <span class="platformResultNextArrow">
                            <svg xmlns="http://www.w3.org/2000/svg" width="26" height="22" viewBox="0 0 26 22" fill="none">
                                <path d="M15.8129 20.9813L25.4122 11.382C25.6081 11.1861 25.7181 10.9205 25.7181 10.6436C25.7181 10.3666 25.6081 10.101 25.4122 9.90515L15.8129 0.305849C15.6171 0.110011 15.3515 -1.03086e-05 15.0745 -1.0983e-05C14.7976 -1.014e-05 14.5319 0.11001 14.3361 0.305848C14.1403 0.501686 14.0303 0.7673 14.0303 1.04426C14.0303 1.32121 14.1403 1.58683 14.3361 1.78266L22.1531 9.59963L1.04478 9.59871C0.767665 9.59871 0.501903 9.70879 0.305957 9.90474C0.11001 10.1007 -7.1796e-05 10.3664 -7.17854e-05 10.6436C-7.1796e-05 10.9207 0.11001 11.1864 0.305957 11.3824C0.501903 11.5783 0.767665 11.6884 1.04478 11.6884L22.1531 11.6875L14.3361 19.5044C14.1403 19.7003 14.0303 19.9659 14.0303 20.2429C14.0303 20.5198 14.1403 20.7854 14.3361 20.9813C14.5319 21.1771 14.7976 21.2871 15.0745 21.2871C15.3515 21.2871 15.6171 21.1771 15.8129 20.9813Z" fill="#19060F"/>
                            </svg>
                        </span>
                    </div>
                </div>
            <?php endwhile; ?>
        <?php endif; ?>
    </div>
    <div class="resultSectionBG">
        <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 2168 658" fill="none">
            <g filter="url(#filter0_f_952_6788)">
                <path d="M1891.15 658C1891.15 517.314 1806.12 382.39 1654.74 282.91C1503.37 183.43 1298.07 127.542 1084 127.542C869.929 127.542 664.626 183.43 513.255 282.91C361.885 382.39 276.845 517.314 276.845 658L1891.15 658Z" fill="url(#paint0_linear_952_6788)" fill-opacity="0.984314"/>
            </g>
            <defs>
                <filter id="filter0_f_952_6788" x="-123.155" y="-272.458" width="2414.31" height="1330.46" filterUnits="userSpaceOnUse" color-interpolation-filters="sRGB">
                    <feFlood flood-opacity="0" result="BackgroundImageFix"/>
                    <feBlend mode="normal" in="SourceGraphic" in2="BackgroundImageFix" result="shape"/>
                    <feGaussianBlur stdDeviation="200" result="effect1_foregroundBlur_952_6788"/>
                </filter>
                <linearGradient id="paint0_linear_952_6788" x1="1084" y1="658" x2="1109.13" y2="-74.7586" gradientUnits="userSpaceOnUse">
                    <stop stop-color="#01D3C7"/>
                    <stop offset="0.151345" stop-color="#08A8A2" stop-opacity="0.57"/>
                    <stop offset="0.237738" stop-color="#0B908E" stop-opacity="0.49"/>
                    <stop offset="0.320429" stop-color="#0F797A" stop-opacity="0.34"/>
                    <stop offset="0.43204" stop-color="#14595F" stop-opacity="0.28"/>
                    <stop offset="0.740931" stop-color="#210214" stop-opacity="0"/>
                    <stop offset="1" stop-color="#210214"/>
                </linearGradient>
            </defs>
        </svg>
    </div>
</section>

<section class="talkToPartnerSec oneInstrumentSec">
    <div class="secWrapper">
        <div class="imgBox">
            <img src="<?php bloginfo('template_directory');?>/images/talk-to-partner-bg.webp" alt="" class="desktopBg">
            <img src="<?php bloginfo('template_directory');?>/images/talk-to-partner-bg-mbl.webp" alt="" class="mblBg">
        </div>
        <?php if( have_rows('talk_to_partner') ): ?>
            <?php while( have_rows('talk_to_partner') ): the_row(); ?>
                <div class="secHeading">
                    <h3 class="manrope"><?php echo get_sub_field('sub_heading'); ?></h3>
                    <h2 class="manrope"><?php echo get_sub_field('heading'); ?></h2>
                    <p><?php echo get_sub_field('description'); ?></p>
                    <a href="<?php echo get_sub_field('cta_link'); ?>" class="primaryCTA"><span><?php echo get_sub_field('cta_text'); ?></span>
                        <div class="arrowBox">
                            <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none">
                                <path d="M18.7504 15.7496V5.99958C18.7504 5.80067 18.6714 5.6099 18.5307 5.46925C18.3901 5.3286 18.1993 5.24958 18.0004 5.24958H8.25042C8.0515 5.24958 7.86074 5.3286 7.72009 5.46925C7.57943 5.6099 7.50042 5.80067 7.50042 5.99958C7.50042 6.19849 7.57943 6.38926 7.72009 6.52991C7.86074 6.67057 8.0515 6.74958 8.25042 6.74958H16.1901L5.46979 17.469C5.32906 17.6097 5.25 17.8006 5.25 17.9996C5.25 18.1986 5.32906 18.3895 5.46979 18.5302C5.61052 18.6709 5.80139 18.75 6.00042 18.75C6.19944 18.75 6.39031 18.6709 6.53104 18.5302L17.2504 7.8099V15.7496C17.2504 15.9485 17.3294 16.1393 17.4701 16.2799C17.6107 16.4206 17.8015 16.4996 18.0004 16.4996C18.1993 16.4996 18.3901 16.4206 18.5307 16.2799C18.6714 16.1393 18.7504 15.9485 18.7504 15.7496Z" fill="#19060F"/>
                            </svg>
                        </div>
                    </a>
                </div>
            <?php endwhile; ?>
        <?php endif; ?>
    </div>
</section>

<?php get_footer(); ?>