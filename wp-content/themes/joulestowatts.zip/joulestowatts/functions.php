<?php
/**
 * joulestowatts functions and definitions
 *
 * @link https://developer.wordpress.org/themes/basics/theme-functions/
 *
 * @package joulestowatts
 */

if ( ! defined( '_S_VERSION' ) ) {
	// Replace the version number of the theme on each release.
	define( '_S_VERSION', '1.0.0' );
}

/**
 * Sets up theme defaults and registers support for various WordPress features.
 *
 * Note that this function is hooked into the after_setup_theme hook, which
 * runs before the init hook. The init hook is too late for some features, such
 * as indicating support for post thumbnails.
 */
function joulestowatts_setup() {
	/*
		* Make theme available for translation.
		* Translations can be filed in the /languages/ directory.
		* If you're building a theme based on joulestowatts, use a find and replace
		* to change 'joulestowatts' to the name of your theme in all the template files.
		*/
	load_theme_textdomain( 'joulestowatts', get_template_directory() . '/languages' );

	// Add default posts and comments RSS feed links to head.
	add_theme_support( 'automatic-feed-links' );

	/*
		* Let WordPress manage the document title.
		* By adding theme support, we declare that this theme does not use a
		* hard-coded <title> tag in the document head, and expect WordPress to
		* provide it for us.
		*/
	add_theme_support( 'title-tag' );

	/*
		* Enable support for Post Thumbnails on posts and pages.
		*
		* @link https://developer.wordpress.org/themes/functionality/featured-images-post-thumbnails/
		*/
	add_theme_support( 'post-thumbnails' );

	// This theme uses wp_nav_menu() in one location.
	register_nav_menus(
		array(
			'menu-1' => esc_html__( 'Primary', 'joulestowatts' ),
			'Footer-Menu-One' => esc_html__( 'Footer Menu One', 'joulestowatts' ),
			'Footer-Menu-Two' => esc_html__( 'Footer Menu Two', 'joulestowatts' ),
			'Footer-Menu-Three' => esc_html__( 'Footer Menu Three', 'joulestowatts' ),
		)
	);

	/*
		* Switch default core markup for search form, comment form, and comments
		* to output valid HTML5.
		*/
	add_theme_support(
		'html5',
		array(
			'search-form',
			'comment-form',
			'comment-list',
			'gallery',
			'caption',
			'style',
			'script',
		)
	);

	// Set up the WordPress core custom background feature.
	add_theme_support(
		'custom-background',
		apply_filters(
			'joulestowatts_custom_background_args',
			array(
				'default-color' => 'ffffff',
				'default-image' => '',
			)
		)
	);

	// Add theme support for selective refresh for widgets.
	add_theme_support( 'customize-selective-refresh-widgets' );

	/**
	 * Add support for core custom logo.
	 *
	 * @link https://codex.wordpress.org/Theme_Logo
	 */
	add_theme_support(
		'custom-logo',
		array(
			'height'      => 250,
			'width'       => 250,
			'flex-width'  => true,
			'flex-height' => true,
		)
	);
}
add_action( 'after_setup_theme', 'joulestowatts_setup' );

/**
 * Set the content width in pixels, based on the theme's design and stylesheet.
 *
 * Priority 0 to make it available to lower priority callbacks.
 *
 * @global int $content_width
 */
function joulestowatts_content_width() {
	$GLOBALS['content_width'] = apply_filters( 'joulestowatts_content_width', 640 );
}
add_action( 'after_setup_theme', 'joulestowatts_content_width', 0 );

/**
 * Register widget area.
 *
 * @link https://developer.wordpress.org/themes/functionality/sidebars/#registering-a-sidebar
 */
function joulestowatts_widgets_init() {
	register_sidebar(
		array(
			'name'          => esc_html__( 'Sidebar', 'joulestowatts' ),
			'id'            => 'sidebar-1',
			'description'   => esc_html__( 'Add widgets here.', 'joulestowatts' ),
			'before_widget' => '<section id="%1$s" class="widget %2$s">',
			'after_widget'  => '</section>',
			'before_title'  => '<h2 class="widget-title">',
			'after_title'   => '</h2>',
		)
	);
}
add_action( 'widgets_init', 'joulestowatts_widgets_init' );

/**
 * Enqueue scripts and styles.
 */
function joulestowatts_scripts() {
	wp_enqueue_style( 'joulestowatts-style', get_stylesheet_uri(), array(), _S_VERSION );
	wp_style_add_data( 'joulestowatts-style', 'rtl', 'replace' );

	wp_enqueue_script( 'joulestowatts-navigation', get_template_directory_uri() . '/js/navigation.js', array(), _S_VERSION, true );

	if ( is_singular() && comments_open() && get_option( 'thread_comments' ) ) {
		wp_enqueue_script( 'comment-reply' );
	}
}
add_action( 'wp_enqueue_scripts', 'joulestowatts_scripts' );

/**
 * Implement the Custom Header feature.
 */
require get_template_directory() . '/inc/custom-header.php';

/**
 * Custom template tags for this theme.
 */
require get_template_directory() . '/inc/template-tags.php';

/**
 * Functions which enhance the theme by hooking into WordPress.
 */
require get_template_directory() . '/inc/template-functions.php';

/**
 * Customizer additions.
 */
require get_template_directory() . '/inc/customizer.php';

/**
 * Load Jetpack compatibility file.
 */
if ( defined( 'JETPACK__VERSION' ) ) {
	require get_template_directory() . '/inc/jetpack.php';
}

require get_template_directory() . '/inc/blocks.php';

// Template Setting - functions.php
if( function_exists('acf_add_options_page') ) {
	acf_add_options_page(array(
		'page_title'  => 'Theme General Settings',
		'menu_title'  => 'Theme Settings',
		'menu_slug'   => 'theme-general-settings',
		'capability'  => 'edit_posts',
		'redirect'    => false
	));
	acf_add_options_sub_page(array(
		'page_title'  => 'Theme Footer Settings',
		'menu_title'  => 'Footer Settings',
		'parent_slug' => 'theme-general-settings',
	));
}

/**
 * Footer menus: wrap each link label in .linkGroup (default + hover text)
 * so the slide-up hover effect in the footer keeps working.
 */
function joulestowatts_footer_menu_item_title( $title, $item, $args, $depth ) {
	if ( ! empty( $args->theme_location ) && 0 === strpos( $args->theme_location, 'Footer-Menu-' ) ) {
		$title = '<div class="linkGroup"><div class="text-default">' . $title . '</div><div class="text-hover">' . $title . '</div></div>';
	}

	return $title;
}
add_filter( 'nav_menu_item_title', 'joulestowatts_footer_menu_item_title', 10, 4 );

/**
 * Header slide-in menu: headings with their links underneath.
 * If a menu is assigned to the "Primary" location, its top-level items become
 * the headings and their children the links. Otherwise the default below is used.
 */
function joulestowatts_main_menu_groups() {
	$locations = get_nav_menu_locations();
	$items     = ! empty( $locations['menu-1'] ) ? wp_get_nav_menu_items( $locations['menu-1'] ) : array();

	if ( $items ) {
		$groups = array();
		foreach ( $items as $item ) {
			if ( ! $item->menu_item_parent ) {
				$groups[ $item->ID ] = array( 'label' => $item->title, 'url' => $item->url, 'links' => array() );
			}
		}
		foreach ( $items as $item ) {
			if ( $item->menu_item_parent && isset( $groups[ $item->menu_item_parent ] ) ) {
				$groups[ $item->menu_item_parent ]['links'][] = array( 'label' => $item->title, 'url' => $item->url );
			}
		}
		return array_values( $groups );
	}

	return array(
		array( 'label' => 'Home', 'url' => home_url( '/' ), 'links' => array() ),
		array(
			'label' => 'The Platform',
			'url'   => home_url( '/platform/' ),
			'links' => array(
				array( 'label' => 'AI Atlas', 'url' => home_url( '/ai-atlas/' ) ),
				array( 'label' => 'ECA', 'url' => home_url( '/enterprise-context-architects/' ) ),
				array( 'label' => 'Talos', 'url' => home_url( '/talos/' ) ),
				array( 'label' => 'GCC Accelerator', 'url' => home_url( '/gcc-accelerator/' ) ),
			),
		),
		array(
			'label' => 'Our Offerings',
			'url'   => home_url( '/platform/#offerings' ),
			'links' => array(
				array( 'label' => 'Managed Pods', 'url' => home_url( '/managed-ai-pods/' ) ),
				array( 'label' => 'Talent Solutions', 'url' => home_url( '/workforce-solutions/' ) ),
				array( 'label' => 'AI Accelerators and Agents', 'url' => home_url( '/ai-accelerators-and-agents/' ) ),
				array( 'label' => 'GCC Accelerator', 'url' => home_url( '/greenfield-consulting/' ) ),
			),
		),
	);
}

/**
 * Case studies post type. Stories live at /case-study/<name>/ so they never
 * clash with the listing page at /case-studies/.
 */
function joulestowatts_register_case_study() {
	register_post_type(
		'case_study',
		array(
			'labels'          => array(
				'name'               => 'Case Studies',
				'singular_name'      => 'Case Study',
				'add_new_item'       => 'Add New Case Study',
				'edit_item'          => 'Edit Case Study',
				'new_item'           => 'New Case Study',
				'view_item'          => 'View Case Study',
				'search_items'       => 'Search Case Studies',
				'not_found'          => 'No case studies found',
				'not_found_in_trash' => 'No case studies found in Trash',
				'all_items'          => 'All Case Studies',
				'menu_name'          => 'Case Studies',
			),
			'public'          => true,
			'has_archive'     => false,
			'show_in_rest'    => true,
			'menu_position'   => 21,
			'menu_icon'       => 'dashicons-chart-line',
			'supports'        => array( 'title', 'page-attributes', 'revisions' ),
			'rewrite'         => array(
				'slug'       => 'case-study',
				'with_front' => false,
			),
			'capability_type' => 'post',
		)
	);
}
add_action( 'init', 'joulestowatts_register_case_study' );

/**
 * Case studies listing filters, in order: the case_study field name (inside the
 * "filters" group), the label field on the listing page, and the default label.
 */
function joulestowatts_case_study_filter_groups() {
	return array(
		'sector'             => array( 'sector_label', 'Sector' ),
		'intervention'       => array( 'intervention_label', 'Intervention' ),
		'impact_on'          => array( 'impact_label', 'Impact on' ),
		'nature_of_solution' => array( 'nature_label', 'Nature of solution' ),
	);
}

/**
 * Choices of one filter field on the case study fields (editable in ACF).
 */
function joulestowatts_case_study_filter_choices( $name ) {
	if ( ! function_exists( 'acf_get_fields' ) ) {
		return array();
	}
	foreach ( acf_get_fields( 'group_6ae05c1a58180' ) as $field ) {
		if ( 'filters' !== $field['name'] ) {
			continue;
		}
		foreach ( $field['sub_fields'] as $sub_field ) {
			if ( $name === $sub_field['name'] ) {
				return (array) $sub_field['choices'];
			}
		}
	}
	return array();
}

/**
 * Published case studies in menu order, optionally leaving one out.
 */
function joulestowatts_case_study_posts( $exclude = 0 ) {
	return get_posts(
		array(
			'post_type'        => 'case_study',
			'post_status'      => 'publish',
			'numberposts'      => -1,
			'orderby'          => array(
				'menu_order' => 'ASC',
				'date'       => 'DESC',
			),
			'exclude'          => $exclude ? array( $exclude ) : array(),
			'suppress_filters' => false,
		)
	);
}

/**
 * Contact form: the "week" dropdown always offers the coming weeks,
 * starting with the week after this one ("Week of 2 November").
 */
function joulestowatts_contact_week_options( $count = 8 ) {
	$monday  = new DateTimeImmutable( 'monday next week', wp_timezone() );
	$options = array();
	for ( $i = 0; $i < $count; $i++ ) {
		$options[] = 'Week of ' . wp_date( 'j F', $monday->modify( "+{$i} week" )->getTimestamp() );
	}
	return $options;
}

function joulestowatts_contact_week_tag( $tag ) {
	if ( 'select' !== $tag['basetype'] || 'week' !== $tag['name'] ) {
		return $tag;
	}
	$weeks             = joulestowatts_contact_week_options();
	$tag['values']     = $weeks;
	$tag['raw_values'] = $weeks;
	$tag['labels']     = $weeks;
	return $tag;
}
add_filter( 'wpcf7_form_tag', 'joulestowatts_contact_week_tag' );
