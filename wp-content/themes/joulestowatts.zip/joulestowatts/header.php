<?php
/**
 * The header for our theme
 *
 * This is the template that displays all of the <head> section and everything up until <div id="content">
 *
 * @link https://developer.wordpress.org/themes/basics/template-files/#template-partials
 *
 * @package joulestowatts
 */

?>
<!doctype html>
<html <?php language_attributes(); ?>>
<head>
	<meta charset="<?php bloginfo( 'charset' ); ?>">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<link rel="profile" href="https://gmpg.org/xfn/11">
	<link href="<?php bloginfo('template_directory'); ?>/css/slick.min.css" rel="stylesheet">
	<link href="<?php bloginfo('template_directory'); ?>/css/slick-theme.css" rel="stylesheet">
    <link href="<?php bloginfo('template_directory'); ?>/css/main.css" rel="stylesheet">

	<?php wp_head(); ?>
</head>

<body <?php body_class(); ?>>
<?php wp_body_open(); ?>
<div id="page" class="site">
	
<header>
	<div class="logoBox">
		<!-- <?php the_custom_logo();?> -->
		<a href="<?php echo esc_url( home_url( '/' ) ); ?>" rel="home">
			<img src="<?php bloginfo('template_directory'); ?>/images/bigger-logo.png" alt="Joules to Watts" class="logo" />
		</a>
	</div>
	<div class="menuBox">
		<a href="<?php the_field('header_cta_link','option'); ?>" class="primaryCTA"><?php the_field('header_cta_text','option'); ?>
			<div class="arrowBox">
				<svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none">
					<path d="M18.7504 15.7496V5.99958C18.7504 5.80067 18.6714 5.6099 18.5307 5.46925C18.3901 5.3286 18.1993 5.24958 18.0004 5.24958H8.25042C8.0515 5.24958 7.86074 5.3286 7.72009 5.46925C7.57943 5.6099 7.50042 5.80067 7.50042 5.99958C7.50042 6.19849 7.57943 6.38926 7.72009 6.52991C7.86074 6.67057 8.0515 6.74958 8.25042 6.74958H16.1901L5.46979 17.469C5.32906 17.6097 5.25 17.8006 5.25 17.9996C5.25 18.1986 5.32906 18.3895 5.46979 18.5302C5.61052 18.6709 5.80139 18.75 6.00042 18.75C6.19944 18.75 6.39031 18.6709 6.53104 18.5302L17.2504 7.8099V15.7496C17.2504 15.9485 17.3294 16.1393 17.4701 16.2799C17.6107 16.4206 17.8015 16.4996 18.0004 16.4996C18.1993 16.4996 18.3901 16.4206 18.5307 16.2799C18.6714 16.1393 18.7504 15.9485 18.7504 15.7496Z" fill="#19060F"/>
				</svg>
			</div>
		</a>
		<div class="hamburger">
			<div class="line"></div>
			<div class="line"></div>
			<div class="line"></div>
		</div>
		<div class="mainMenu" aria-label="Main menu">
			<nav>
				<ul class="menuGroups">
					<li class="menuGroup">
						<a href="<?php echo get_site_url(); ?>/" class="menuHeading manrope">Home</a>
					</li>
					<li class="menuGroup">
						<a href="<?php echo get_site_url(); ?>/platform" class="menuHeading manrope">Platform</a>
					</li>
					<li class="menuGroup">
						<a href="#" class="menuHeading manrope">The Proprietary IP</a>
						<ul class="menuLinks">
							<li><a href="<?php echo get_site_url(); ?>/ai-atlas" class="manrope">AI Atlas</a></li>
							<li><a href="<?php echo get_site_url(); ?>/enterprise-context-architects" class="manrope">Enterprise Context Architects</a></li>
							<li><a href="<?php echo get_site_url(); ?>/talos" class="manrope">Talos</a></li>
							<li><a href="<?php echo get_site_url(); ?>/gcc-accelerator" class="manrope">Greenfield Accelerator</a></li>
						</ul>
					</li>
					<li class="menuGroup">
						<a href="#" class="menuHeading manrope">Our Offerings</a>
						<ul class="menuLinks">
							<li><a href="<?php echo get_site_url(); ?>/talent-solutions" class="manrope">Talent Solutions: talent composition</a></li>
							<li><a href="<?php echo get_site_url(); ?>/managed-ai-pods" class="manrope">Managed Talent Pods</a></li>
							<li><a href="<?php echo get_site_url(); ?>/ai-accelerators-and-agents" class="manrope">AI accelerators and agents</a></li>
							<li><a href="<?php echo get_site_url(); ?>/greenfield-consulting" class="manrope">Greenfield: consulting + set up</a></li>
						</ul>
					</li>
					<li class="menuGroup">
						<a href="<?php echo get_site_url(); ?>/case-studies" class="menuHeading manrope">Customer Success stories</a>
					</li>
					<li class="menuGroup">
						<a href="<?php echo get_site_url(); ?>/about-us" class="menuHeading manrope">About us</a>
					</li>
					<li class="menuGroup">
						<a href="<?php echo get_site_url(); ?>/careers" class="menuHeading manrope">Careers</a>
					</li>
					<li class="menuGroup">
						<a href="<?php echo get_site_url(); ?>/contact-us" class="menuHeading manrope">Contact Us</a>
					</li>
				</ul>
			</nav>
		</div>
	</div>
</header>
<div class="menuBackdrop" aria-hidden="true"></div>

