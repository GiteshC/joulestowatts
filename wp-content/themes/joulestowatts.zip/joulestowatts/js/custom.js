gsap.registerPlugin(ScrollTrigger);

ScrollTrigger.create({
	start: function () {
		return window.innerHeight * 0.2;
	},
	onEnter: () => {
		document.querySelector("header").classList.add("scrolled");
	},
	onLeaveBack: () => {
		document.querySelector("header").classList.remove("scrolled");
	},
});

// Header — hamburger toggles the slide-in main menu (and morphs into a close icon).
(function () {
	"use strict";

	document.addEventListener("DOMContentLoaded", function () {
		var header = document.querySelector("header");
		var burger = header ? header.querySelector(".hamburger") : null;
		var menu = header ? header.querySelector(".mainMenu") : null;

		if (!burger || !menu) {
			return;
		}

		// Make the div behave like a proper button for keyboard/screen readers.
		menu.id = menu.id || "mainMenu";
		burger.setAttribute("role", "button");
		burger.setAttribute("tabindex", "0");
		burger.setAttribute("aria-controls", menu.id);
		burger.setAttribute("aria-label", "Open menu");
		burger.setAttribute("aria-expanded", "false");

		var backdrop = document.querySelector(".menuBackdrop");

		function setOpen(open) {
			header.classList.toggle("menu-open", open);
			document.body.classList.toggle("menu-is-open", open);
			burger.setAttribute("aria-expanded", open ? "true" : "false");
			burger.setAttribute(
				"aria-label",
				open ? "Close menu" : "Open menu",
			);
		}

		burger.addEventListener("click", function () {
			setOpen(!header.classList.contains("menu-open"));
		});

		burger.addEventListener("keydown", function (e) {
			if (e.key === "Enter" || e.key === " ") {
				e.preventDefault();
				burger.click();
			}
		});

		// Close by clicking the dimmed page behind the menu.
		if (backdrop) {
			backdrop.addEventListener("click", function () {
				setOpen(false);
			});
		}

		// Close after picking a link, or with Escape.
		menu.querySelectorAll("a").forEach(function (link) {
			link.addEventListener("click", function () {
				setOpen(false);
			});
		});

		document.addEventListener("keydown", function (e) {
			if (e.key === "Escape") {
				setOpen(false);
			}
		});
	});
})();

//Ai Section
if ($(".ourAiSection").length) {
	window.addEventListener("load", () => {
		const DEBUG = false;
		const SNAP = false; // snap chahiye to true

		if (
			typeof gsap === "undefined" ||
			typeof ScrollTrigger === "undefined"
		) {
			console.error("GSAP ya ScrollTrigger load nahi hua");
			return;
		}
		gsap.registerPlugin(ScrollTrigger);

		const section = document.querySelector("#ips");
		if (!section) return;

		const right = section.querySelector(".righttextPart");
		const track = section.querySelector(".track");
		const cards = gsap.utils.toArray(".aiImgBox", track);
		const panels = gsap.utils.toArray(
			".cardHeadingGroup .cardHeading",
			section,
		);
		const n = cards.length;

		if (!right || !track || n < 2 || panels.length !== n) {
			console.error("Setup galat:", { cards: n, panels: panels.length });
			return;
		}

		const cssVar = (name) =>
			parseFloat(getComputedStyle(section).getPropertyValue(name));

		// card i ko container ke bilkul beech me laane ke liye track ka y
		const yFor = (i) =>
			right.clientHeight / 2 -
			(cards[i].offsetTop + cards[i].offsetHeight / 2);

		function build() {
			const inactiveScale = cssVar("--inactive-scale") || 0.9;
			const inactiveOpacity = cssVar("--inactive-opacity") || 0.4;

			// ---- left panels ----
			let current = 0;
			function swap(i) {
				if (i === current) return;
				const dir = i > current ? 1 : -1;
				const inn = panels[i];
				current = i;

				gsap.killTweensOf(panels);
				panels.forEach((p) => gsap.killTweensOf(p.children));

				panels.forEach((p) => {
					if (p !== inn) {
						gsap.to(p, {
							autoAlpha: 0,
							y: -16 * dir,
							duration: 0.2,
							ease: "power2.in",
						});
					}
				});
				gsap.fromTo(
					inn,
					{ autoAlpha: 0, y: 24 * dir },
					{
						autoAlpha: 1,
						y: 0,
						duration: 0.45,
						delay: 0.15,
						ease: "power3.out",
					},
				);
				gsap.fromTo(
					inn.children,
					{ opacity: 0, y: 14 * dir },
					{
						opacity: 1,
						y: 0,
						duration: 0.45,
						delay: 0.18,
						stagger: 0.06,
						ease: "power3.out",
					},
				);
			}

			// ---- ek timeline: har segment = 1 unit = ek card ka move ----
			const tl = gsap.timeline({
				defaults: { ease: "none" },
				scrollTrigger: {
					trigger: section,
					start: () =>
						section.offsetHeight < window.innerHeight
							? "center center"
							: "top top",
					end: () => "+=" + (n - 1) * window.innerHeight * 0.8,
					pin: true,
					pinSpacing: true,
					anticipatePin: 1,
					scrub: true,
					markers: DEBUG,
					snap: SNAP
						? {
								snapTo: 1 / (n - 1),
								duration: { min: 0.2, max: 0.5 },
								ease: "power1.inOut",
								delay: 0.05,
							}
						: false,
					invalidateOnRefresh: true,
					onUpdate: (self) =>
						swap(Math.round(self.progress * (n - 1))),
				},
			});

			// track: card i se card i+1 tak
			for (let i = 0; i < n - 1; i++) {
				tl.fromTo(
					track,
					{ y: () => yFor(i) },
					{
						y: () => yFor(i + 1),
						duration: 1,
						immediateRender: i === 0,
					},
					i,
				);
			}

			// cards: aate waqt active, jaate waqt inactive
			cards.forEach((c, i) => {
				if (i > 0) {
					tl.fromTo(
						c,
						{ opacity: inactiveOpacity, scale: inactiveScale },
						{ opacity: 1, scale: 1, duration: 1 },
						i - 1,
					);
				}
				if (i < n - 1) {
					tl.fromTo(
						c,
						{ opacity: 1, scale: 1 },
						{
							opacity: inactiveOpacity,
							scale: inactiveScale,
							duration: 1,
							immediateRender: false,
						},
						i,
					);
				}
			});

			// cleanup: breakpoint badalne par sab CSS ke initial state par wapas
			return () => {
				gsap.killTweensOf(panels);
				panels.forEach((p) => gsap.killTweensOf(p.children));
				gsap.set(panels, { clearProps: "all" });
				panels.forEach((p) =>
					gsap.set(p.children, { clearProps: "all" }),
				);
				gsap.set(cards, { clearProps: "all" });
				gsap.set(track, { clearProps: "all" });
			};
		}

		// breakpoint badle to naye CSS variables ke saath dobara build hoga
		const mm = gsap.matchMedia();
		mm.add(
			{
				desktop: "(min-width: 1081px)",
				mobile: "(min-width: 1081px)",
			},
			(ctx) => {
				const { tablet } = ctx.conditions;
				return build(tablet); // pass a flag and use e.g. 0.6 instead of 0.8 for scroll distance
			},
		);

		// images late load hon to ek baar refresh
		let t;
		track.querySelectorAll("img").forEach((img) => {
			if (!img.complete) {
				img.addEventListener("load", () => {
					clearTimeout(t);
					t = setTimeout(() => ScrollTrigger.refresh(), 150);
				});
			}
		});
	});
}

// Banner heading — letter-by-letter typing effect on the plain text only.
// Anything wrapped in a child element (e.g. <span>Amplified</span>) is left alone.
(function () {
	"use strict";

	function initBannerTyping() {
		var heading = document.querySelector(".bannerSection h1");

		if (!heading || typeof gsap === "undefined") {
			return;
		}

		if (window.matchMedia("(prefers-reduced-motion: reduce)").matches) {
			return;
		}

		var chars = [];

		// The stylesheet's `h1 span` gradient rule would also hit the spans we
		// create here, so force them back to plain white text.
		function makePlain(el) {
			el.style.background = "none";
			el.style.webkitTextFillColor = "currentColor";
		}

		// Keep the full sentence readable for screen readers / SEO.
		heading.setAttribute(
			"aria-label",
			heading.textContent.replace(/\s+/g, " ").trim(),
		);

		// Only the h1's own text nodes (not the ones inside <span>).
		Array.prototype.slice.call(heading.childNodes).forEach(function (node) {
			if (node.nodeType !== 3 || !node.textContent.trim()) {
				return;
			}

			var text = node.textContent;
			var parts = text.split(/\s+/).filter(Boolean);
			var frag = document.createDocumentFragment();

			// Keep the spaces at the edges of the text (e.g. the space
			// between "Truth" and <span>Amplified</span>).
			if (/^\s/.test(text)) {
				frag.appendChild(document.createTextNode(" "));
			}

			parts.forEach(function (word, i) {
				var wordSpan = document.createElement("span");

				wordSpan.className = "typeWord";
				wordSpan.style.whiteSpace = "nowrap";
				wordSpan.setAttribute("aria-hidden", "true");
				makePlain(wordSpan);

				word.split("").forEach(function (letter) {
					var charSpan = document.createElement("span");

					charSpan.className = "typeChar";
					charSpan.style.display = "inline-block";
					makePlain(charSpan);
					charSpan.textContent = letter;
					wordSpan.appendChild(charSpan);
					chars.push(charSpan);
				});

				frag.appendChild(wordSpan);

				if (i < parts.length - 1) {
					frag.appendChild(document.createTextNode(" "));
				}
			});

			if (/\s$/.test(text)) {
				frag.appendChild(document.createTextNode(" "));
			}

			heading.replaceChild(frag, node);
		});

		if (!chars.length) {
			return;
		}

		// Letters start hidden and slightly lower (autoAlpha keeps layout stable).
		gsap.set(chars, { autoAlpha: 0, y: 20 });

		gsap.to(chars, {
			autoAlpha: 1,
			y: 0,
			duration: 0.5,
			ease: "power2.out",
			stagger: 0.05,
			delay: 0.3,
		});
	}

	if (document.readyState === "loading") {
		document.addEventListener("DOMContentLoaded", initBannerTyping);
	} else {
		initBannerTyping();
	}
})();

(function () {
	"use strict";
	document.addEventListener("DOMContentLoaded", function () {
		var section = document.querySelector(".enterpriseSection");
		if (!section) {
			return;
		}
		// GSAP + ScrollTrigger are expected to be loaded already (enqueued
		// in header.php, before this script runs in the footer).
		if (
			typeof gsap === "undefined" ||
			typeof ScrollTrigger === "undefined"
		) {
			// Fail safe: if GSAP didn't load for any reason, don't leave
			// the section stuck invisible.
			return;
		}
		gsap.registerPlugin(ScrollTrigger);
		var reduceMotion = window.matchMedia(
			"(prefers-reduced-motion: reduce)",
		).matches;
		var globe = section.querySelector(".globeEffect");
		var content = section.querySelector(".enterpriseContent");
		if (reduceMotion || !globe || !content) {
			return;
		}
		gsap.timeline({
			scrollTrigger: {
				trigger: section,
				start: "top 80%",
				toggleActions: "restart none restart none",
			},
		})
			.fromTo(
				globe,
				{ opacity: 0, y: 150 },
				{ opacity: 1, y: 0, duration: 0.9, ease: "power2.out" },
			)
			.fromTo(
				content,
				{ opacity: 0, y: 150 },
				{ opacity: 1, y: 0, duration: 0.9, ease: "power2.out" },
				"-=0.75",
			);
	});
})();

// What We Do — each content box slides in from the right edge of the screen.
(function () {
	"use strict";
	document.addEventListener("DOMContentLoaded", function () {
		var section = document.querySelector(".whatwedoSection");
		if (
			!section ||
			typeof gsap === "undefined" ||
			typeof ScrollTrigger === "undefined"
		) {
			return;
		}
		var boxes = section.querySelectorAll(".contentBox");
		if (!boxes.length) {
			return;
		}
		var reduceMotion = window.matchMedia(
			"(prefers-reduced-motion: reduce)",
		).matches;
		if (reduceMotion) {
			return;
		}
		boxes.forEach(function (box) {
			gsap.fromTo(
				box,
				{ opacity: 0, x: "100vw" },
				{
					opacity: 1,
					x: 0,
					duration: 1.5,
					delay: 0.5,
					ease: "power2.out",
					scrollTrigger: {
						trigger: box,
						start: "top 85%",
						toggleActions: "restart none restart none",
					},
				},
			);
		});
	});
})();

// Counter section — each number animates from 0 up to its target value
// once it scrolls into view.
(function () {
	"use strict";
	document.addEventListener("DOMContentLoaded", function () {
		var counters = document.querySelectorAll(
			".counterSection .counterBox h4",
		);
		if (
			!counters.length ||
			typeof gsap === "undefined" ||
			typeof ScrollTrigger === "undefined"
		) {
			return;
		}
		var reduceMotion = window.matchMedia(
			"(prefers-reduced-motion: reduce)",
		).matches;
		counters.forEach(function (counter) {
			// Numbers may contain commas (e.g. "5,500") — strip them to get
			// the numeric target, keep the original for comma formatting.
			var target = parseInt(counter.textContent.replace(/,/g, ""), 10);
			if (isNaN(target)) {
				return;
			}
			if (reduceMotion) {
				counter.textContent = target.toLocaleString("en-US");
				return;
			}
			var counterObj = { value: 0 };
			gsap.to(counterObj, {
				value: target,
				duration: 1.6,
				delay: 0.3,
				ease: "power1.out",
				onUpdate: function () {
					counter.textContent = Math.round(
						counterObj.value,
					).toLocaleString("en-US");
				},
				scrollTrigger: {
					trigger: counter.closest(".counterBox"),
					start: "top 85%",
					toggleActions: "restart none restart none",
				},
			});
		});
	});
})();

// Compounds section — trigger the SVG's inline CSS animations
(function () {
	"use strict";
	document.addEventListener("DOMContentLoaded", function () {
		var section = document.querySelector(".compoundsSection");
		if (
			!section ||
			typeof gsap === "undefined" ||
			typeof ScrollTrigger === "undefined"
		) {
			return;
		}
		ScrollTrigger.create({
			trigger: section,
			start: "top 30%",
			once: true,
			onEnter: function () {
				section.classList.add("in-view");
			},
		});
	});
})();

// Building section — pinned 3-card carousel driven by scroll.
(function () {
	"use strict";

	var EDGE_GAP = 30; // px between screen edge and outer edge of the side cards
	var SIDE_SCALE = 0.85;

	function initBuilding() {
		var section = document.querySelector(".buildingSection");

		if (
			!section ||
			typeof gsap === "undefined" ||
			typeof ScrollTrigger === "undefined"
		) {
			return;
		}

		var slides = gsap.utils.toArray(
			section.querySelectorAll(".cardContainer .slide"),
		);
		var total = slides.length;
		var isDesktop = window.matchMedia("(min-width: 1025px)").matches;
		var reduceMotion = window.matchMedia(
			"(prefers-reduced-motion: reduce)",
		).matches;

		if (total < 2 || !isDesktop || reduceMotion) {
			return;
		}

		gsap.registerPlugin(ScrollTrigger);
		section.classList.add("is-carousel");

		// Side offset (in % of card width) so the side cards' outer edge
		// sits exactly EDGE_GAP px from the screen edge.
		var sideX = 30;

		function measureSide() {
			var w = slides[0].offsetWidth;
			var half = section.clientWidth / 2;

			sideX = Math.max(
				0,
				((half - EDGE_GAP - (SIDE_SCALE * w) / 2) / w) * 100,
			);
		}

		// Position of card i relative to the active card, wrapping around so the
		// last card waits on the left of the first one (as in the design).
		function offset(i, state) {
			var pos = (((i - state) % total) + total) % total;
			return pos > total / 2 ? pos - total : pos;
		}

		function slot(i, state) {
			var pos = offset(i, state);
			var dir = pos < 0 ? -1 : 1;

			if (pos === 0) {
				return { x: 0, scale: 1, opacity: 1 };
			}
			if (Math.abs(pos) === 1) {
				return { x: dir * sideX, scale: SIDE_SCALE, opacity: 0.25 };
			}
			return { x: dir * sideX, scale: 0.75, opacity: 0 };
		}

		function stateVars(state) {
			return {
				xPercent: function (i) {
					return slot(i, state).x;
				},
				scale: function (i) {
					return slot(i, state).scale;
				},
				opacity: function (i) {
					return slot(i, state).opacity;
				},
			};
		}

		function setActive(state) {
			slides.forEach(function (slide, i) {
				slide.classList.toggle("is-active", i === state);
				slide.style.zIndex = total - Math.abs(offset(i, state));
			});
		}

		measureSide();
		gsap.set(slides, stateVars(0));
		setActive(0);

		var tl = gsap.timeline({
			defaults: { duration: 1, ease: "power2.inOut" },
			scrollTrigger: {
				trigger: section,
				start: "top top",
				end: function () {
					return "+=" + (total - 1) * window.innerHeight * 0.9;
				},
				pin: true,
				anticipatePin: 1,
				refreshPriority: 1,
				scrub: 0.6,
				snap: {
					snapTo: 1 / (total - 1),
					duration: { min: 0.2, max: 0.5 },
					ease: "power1.inOut",
				},
				invalidateOnRefresh: true,
				// Re-measure on resize/refresh so the 30px gap stays exact.
				onRefreshInit: function () {
					measureSide();
					gsap.set(slides, stateVars(0));
				},
				onUpdate: function (self) {
					setActive(Math.round(self.progress * (total - 1)));
				},
			},
		});

		for (var s = 1; s < total; s++) {
			tl.to(slides, stateVars(s));
		}

		if (document.fonts && document.fonts.ready) {
			document.fonts.ready.then(function () {
				ScrollTrigger.refresh();
			});
		}
	}

	if (document.readyState === "complete") {
		initBuilding();
	} else {
		window.addEventListener("load", initBuilding);
	}
})();

if (window.innerWidth <= 1024) {
	var $slider = $(".buildingCardSlider");

	function setCenter(slick, targetIndex) {
		var total = slick.slideCount;
		var target = ((targetIndex % total) + total) % total;

		slick.$slider.find(".slick-slide").each(function () {
			var idx = parseInt($(this).attr("data-slick-index"), 10);
			idx = ((idx % total) + total) % total; // clones ko real index me convert
			$(this).toggleClass("is-center", idx === target);
		});
	}

	$slider.on("init", function (e, slick) {
		setCenter(slick, slick.currentSlide);
	});

	$slider.on("beforeChange", function (e, slick, current, next) {
		setCenter(slick, next);
	});

	$slider.slick({
		slidesToShow: 1,
		centerMode: true,
		centerPadding: "10%",
		arrows: false,
		infinite: true,
		speed: 400,
		responsive: [
			{
				breakpoint: 768,
				settings: { centerPadding: "8%", slidesToShow: 1 },
			},
			{
				breakpoint: 721,
				settings: { centerPadding: "5px", slidesToShow: 1 },
			},
		],
	});
}

if (window.innerWidth <= 1024) {
	$(".whyItSlider").slick({
		slidesToShow: 2.6,
		slidesToScroll: 1,
		arrows: false,
		dots: false,
		centerMode: false,
		infinite: false,
		responsive: [
			{
				breakpoint: 720,
				settings: {
					slidesToShow: 1.4,
					slidesToScroll: 1,
				},
			},
		],
	});
}

$(".mainSliderBox").slick({
	slidesToShow: 1,
	slidesToScroll: 1,
	arrows: false,
	fade: true,
	infinite: false,
	asNavFor: ".textSlider",
});
$(".textSlider").slick({
	slidesToShow: 1,
	slidesToScroll: 1,
	arrows: true,
	prevArrow: $(".prevArrow"),
	nextArrow: $(".nextArrow"),
	asNavFor: ".mainSliderBox",
	dots: false,
	fade: true,
	infinite: false,
	centerMode: false,
	focusOnSelect: false,
});

$(document).ready(function () {
	const $slider = $(".resultCardSlider");

	function getSlides() {
		const w = window.innerWidth;
		if (w <= 720) return 1.1;
		if (w <= 1024) return 2.3;
		if (w <= 1280) return 2.8;
		return 3.5;
	}

	$slider.slick({
		slidesToShow: getSlides(),
		slidesToScroll: 1,
		infinite: false,
		arrows: true,
		prevArrow: $(".resultPrevArrow"),
		nextArrow: $(".resultNextArrow"),
	});

	$(window).on("resize", function () {
		$slider.slick("slickSetOption", "slidesToShow", getSlides(), true);
	});
});

//footer accordian
document.addEventListener("DOMContentLoaded", () => {
	const mq = window.matchMedia("(max-width: 768px)");
	const columns = document.querySelectorAll(".footerLinks .column");

	function closeAll() {
		columns.forEach((col) => {
			col.classList.remove("active");
			const links = col.querySelector(".links");
			if (links) links.style.maxHeight = null;
		});
	}

	function toggleColumn(col) {
		const links = col.querySelector(".links");
		const isOpen = col.classList.contains("active");

		// Ek time par ek hi open rahe (chahiye to yeh block hata do)
		columns.forEach((c) => {
			c.classList.remove("active");
			const l = c.querySelector(".links");
			if (l) l.style.maxHeight = null;
		});

		if (!isOpen) {
			col.classList.add("active");
			links.style.maxHeight = links.scrollHeight + 40 + "px";
		}
	}

	columns.forEach((col) => {
		const heading = col.querySelector(".linkHeading");

		heading.addEventListener("click", () => {
			if (!mq.matches) return; // desktop par kuch nahi
			toggleColumn(col);
		});

		// Keyboard accessibility
		heading.setAttribute("tabindex", "0");
		heading.setAttribute("role", "button");
		heading.addEventListener("keydown", (e) => {
			if (!mq.matches) return;
			if (e.key === "Enter" || e.key === " ") {
				e.preventDefault();
				toggleColumn(col);
			}
		});
	});

	// Desktop par switch hone par reset
	mq.addEventListener("change", (e) => {
		if (!e.matches) closeAll();
	});
});

if (window.innerWidth <= 820) {
	document
		.querySelectorAll(
			".whatwedoSection .wrapper .secHeading .headingGroup p",
		)
		.forEach((p) => {
			p.innerHTML = p.innerHTML.replace(/<br\s*\/?>/gi, " ");
		});
}

//Platform page

$(document).ready(function () {
	const $slider = $(".platformResultSlider");
	const $prev = $(".platformResultPrevArrow");
	const $next = $(".platformResultNextArrow");

	function getSlides() {
		const w = window.innerWidth;

		if (w <= 720) return 1.1;
		if (w <= 1024) return 2.3;
		if (w <= 1280) return 2.8;

		return 3.5;
	}

	function updateSlider() {
		const slick = $slider.slick("getSlick");

		const slidesToShow = getSlides();
		const totalSlides = slick.slideCount;

		const showArrows = totalSlides > slidesToShow;

		$slider.slick("slickSetOption", "slidesToShow", slidesToShow, false);
		$slider.slick("slickSetOption", "arrows", showArrows, true);

		// Custom arrows visibility
		$prev.toggle(showArrows);
		$next.toggle(showArrows);
	}

	const slidesToShow = getSlides();

	$slider.slick({
		slidesToShow: slidesToShow,
		slidesToScroll: 1,
		infinite: false,

		autoplay: true,
		autoplaySpeed: 3000,
		speed: 1000,
		cssEase: "ease",

		arrows: true,

		prevArrow: $prev,
		nextArrow: $next,
	});

	updateSlider();

	let resizeTimer;

	$(window).on("resize", function () {
		clearTimeout(resizeTimer);

		resizeTimer = setTimeout(function () {
			updateSlider();
		}, 200);
	});
});

//  platform page — Banner heading and image fade in from below, staggered.
(function () {
	"use strict";

	function initPlatformBanner() {
		var section = document.querySelector(".bannerInnerSection");
		if (!section || typeof gsap === "undefined") {
			return;
		}
		if (window.matchMedia("(prefers-reduced-motion: reduce)").matches) {
			return;
		}

		var heading = section.querySelector(".bannerContent .bannerHeading");
		var image = section.querySelector(".bannerContent > img");

		var items = [heading, image].filter(Boolean);
		if (!items.length) {
			return;
		}

		var DISTANCE = 80;
		var DURATION = 1.8;
		var EASE = "power2.out";
		var START_DELAY = 0.3; // before the heading starts
		var IMAGE_DELAY = 1.2; // extra wait after the heading starts, before the image

		if (heading) {
			gsap.fromTo(
				heading,
				{ y: DISTANCE, autoAlpha: 0 },
				{
					y: 0,
					autoAlpha: 1,
					duration: DURATION,
					ease: EASE,
					delay: START_DELAY,
				},
			);
		}
		if (image) {
			gsap.fromTo(
				image,
				{ y: DISTANCE, autoAlpha: 0 },
				{
					y: 0,
					autoAlpha: 1,
					duration: DURATION,
					ease: EASE,
					delay: START_DELAY + IMAGE_DELAY,
				},
			);
		}
	}

	if (document.readyState === "loading") {
		document.addEventListener("DOMContentLoaded", initPlatformBanner);
	} else {
		initPlatformBanner();
	}
})();

//Solution Section JS
if ($(".solutionSection").length) {
	document.addEventListener("DOMContentLoaded", () => {
		const containers = document.querySelectorAll(
			".secWrapper .cardContainer",
		);

		const mobileQuery = window.matchMedia("(max-width: 820px)");

		containers.forEach((container) => {
			const cards = [...container.querySelectorAll(".solutionCard")];

			if (!cards.length) return;

			function setImageHeight(card, isOpen) {
				const imgBox = card.querySelector(".imgBox");

				if (!imgBox) return;

				if (!mobileQuery.matches || !isOpen) {
					imgBox.style.maxHeight = "";
					return;
				}

				imgBox.style.maxHeight = "100%";

				const updateHeight = () => {
					if (
						!mobileQuery.matches ||
						!card.classList.contains("solutionActiveCard")
					) {
						return;
					}

					imgBox.style.maxHeight = `${imgBox.scrollHeight}px`;
				};

				const img = imgBox.querySelector("img");

				if (img && !img.complete) {
					img.addEventListener("load", updateHeight, { once: true });
					img.addEventListener("error", updateHeight, { once: true });
				} else {
					requestAnimationFrame(updateHeight);
				}
			}

			function openCard(activeCard) {
				if (!mobileQuery.matches) return;

				cards.forEach((card) => {
					const isActive = card === activeCard;

					card.classList.toggle("solutionActiveCard", isActive);
					setImageHeight(card, isActive);
				});
			}

			function closeAllCards() {
				cards.forEach((card) => {
					card.classList.remove("solutionActiveCard");
					setImageHeight(card, false);
				});
			}

			function initializeAccordion() {
				if (mobileQuery.matches) {
					// First card ko sirf tab open karo jab initial setup ho.
					const activeCard = cards.find((card) =>
						card.classList.contains("solutionActiveCard"),
					);

					if (activeCard) {
						openCard(activeCard);
					} else if (!container.dataset.accordionInitialized) {
						openCard(cards[0]);
					}

					container.dataset.accordionInitialized = "true";
				} else {
					closeAllCards();

					cards.forEach((card) => {
						const imgBox = card.querySelector(".imgBox");

						if (imgBox) {
							imgBox.style.maxHeight = "";
						}
					});

					container.dataset.accordionInitialized = "";
				}
			}

			initializeAccordion();

			cards.forEach((card) => {
				card.addEventListener("click", (event) => {
					if (!mobileQuery.matches) return;

					const link = event.target.closest("a");
					const isActive =
						card.classList.contains("solutionActiveCard");

					// Closed card: first click only opens the card
					if (!isActive) {
						if (link) {
							event.preventDefault();
						}

						openCard(card);
						return;
					}

					// Open card: link should work normally
					if (link) {
						return;
					}

					// Open card: clicking outside link closes it
					closeAllCards();
				});
			});

			// Outside click par accordion state change nahi hogi
			document.addEventListener("click", (event) => {
				if (!mobileQuery.matches) return;

				const clickedInside = event.target.closest(
					".secWrapper .cardContainer .solutionCard",
				);

				if (!clickedInside) {
					// Intentionally do nothing
					return;
				}
			});

			if (mobileQuery.addEventListener) {
				mobileQuery.addEventListener("change", initializeAccordion);
			} else {
				mobileQuery.addEventListener(initializeAccordion);
			}

			window.addEventListener("resize", () => {
				if (!mobileQuery.matches) return;

				const activeCard = cards.find((card) =>
					card.classList.contains("solutionActiveCard"),
				);

				if (activeCard) {
					setImageHeight(activeCard, true);
				}
			});
		});
	});
}

// Platform page — Diagnosis section intro:
// heading rises from the section centre to its place, then the image zooms in
// at the centre, then the left box slides in from the left and the right box
// from the right.
(function () {
	"use strict";

	// 1 = base timing below. Higher = slower (1.5 = 50% slower, 2 = twice as slow).
	var SPEED = 1.2;

	var D = {
		heading: 1.2, // heading drops into place
		image: 1.4, // image zoom-in
		label: 1.6, // "AI CHARTER" fade
		side: 1.6, // leftBox / rightBox slide-in
	};
	var GAP = 0.2; // pause between steps (seconds, before SPEED is applied)
	var SIDE_OFFSET = 200;

	function initDiagnosis() {
		var section = document.querySelector(".diagnosisSection");
		if (
			!section ||
			typeof gsap === "undefined" ||
			typeof ScrollTrigger === "undefined"
		) {
			return;
		}
		if (window.matchMedia("(prefers-reduced-motion: reduce)").matches) {
			return;
		}

		var heading = section.querySelector(".secHeading");
		var content = section.querySelector(".diagnosisContent");
		var leftBox = section.querySelector(".leftBox");
		var rightBox = section.querySelector(".rightBox");
		var image = section.querySelector(".middleBox img");
		var label = section.querySelector(".middleBox p");
		if (!heading || !content || !leftBox || !rightBox || !image) {
			return;
		}

		gsap.registerPlugin(ScrollTrigger);

		// Distance from the heading's natural spot to the centre of the content area.
		function headingStartY() {
			var h = heading.getBoundingClientRect();
			var c = content.getBoundingClientRect();
			var current = gsap.getProperty(heading, "y") || 0;
			return c.top + c.height / 2 - (h.top + h.height / 2) + current;
		}

		var tl = gsap.timeline({
			defaults: { ease: "power3.out" },
			scrollTrigger: {
				trigger: section,
				start: "center 80%",
				toggleActions: "restart none restart none",
				invalidateOnRefresh: true,
			},
		});

		// 1. Heading
		tl.fromTo(
			heading,
			{ y: headingStartY, autoAlpha: 0 },
			{ y: 0, autoAlpha: 1, duration: D.heading, ease: "power2.out" },
		);

		// 2. Image zoom (starts while heading is settling)
		tl.fromTo(
			image,
			{ scale: 0.4, autoAlpha: 0, transformOrigin: "50% 50%" },
			{ scale: 1, autoAlpha: 1, duration: D.image, ease: "power2.inOut" },
			">-0.3",
		);

		if (label) {
			tl.fromTo(
				label,
				{ autoAlpha: 0 },
				{ autoAlpha: 1, duration: D.label, ease: "power1.out" },
				"<0.9",
			);
		}

		// 3. Side boxes
		tl.fromTo(
			leftBox,
			{ x: -SIDE_OFFSET, autoAlpha: 0 },
			{ x: 0, autoAlpha: 1, duration: D.side, ease: "power2.out" },
			">" + (GAP - 0.3),
		);
		tl.fromTo(
			rightBox,
			{ x: SIDE_OFFSET, autoAlpha: 0 },
			{ x: 0, autoAlpha: 1, duration: D.side, ease: "power2.out" },
			"<",
		);

		// Slow everything uniformly.
		tl.timeScale(1 / SPEED);

		if (document.fonts && document.fonts.ready) {
			document.fonts.ready.then(function () {
				ScrollTrigger.refresh();
			});
		}
	}

	if (document.readyState === "complete") {
		initDiagnosis();
	} else {
		window.addEventListener("load", initDiagnosis);
	}
})();

// Platform page — Video fullscreen effect: when a video box is clicked, it expands to fill the screen, and shrinks back when closed.
(function () {
	"use strict";

	function initVideoFullscreen() {
		var boxes = document.querySelectorAll(".videofullSection .videoBox");
		if (!boxes.length || typeof gsap === "undefined") {
			return;
		}

		var CLOSE_ICON =
			'<svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="#fff" stroke-width="2" stroke-linecap="round"><path d="M5 5l14 14M19 5L5 19"/></svg>';
		var DUR = 0.8;
		var EASE = "power3.inOut";

		var backdrop = document.createElement("div");
		backdrop.className = "videoBackdrop";
		document.body.appendChild(backdrop);

		var active = null; // { box, video, placeholder, closeBtn }
		var busy = false;

		function open(box) {
			if (active || busy) {
				return;
			}
			busy = true;

			var video = box.querySelector("video");
			var r = box.getBoundingClientRect();

			// Placeholder holds the layout space while the box is fixed.
			var placeholder = document.createElement("div");
			placeholder.className = "videoPlaceholder";
			placeholder.style.width = r.width + "px";
			placeholder.style.height = r.height + "px";
			box.parentNode.insertBefore(placeholder, box);

			var closeBtn = document.createElement("button");
			closeBtn.type = "button";
			closeBtn.className = "closeBtn";
			closeBtn.setAttribute("aria-label", "Close video");
			closeBtn.innerHTML = CLOSE_ICON;
			box.appendChild(closeBtn);

			active = {
				box: box,
				video: video,
				placeholder: placeholder,
				closeBtn: closeBtn,
			};

			// Pin the box exactly where it is, then grow it.
			box.classList.add("is-open");
			gsap.set(box, {
				top: r.top,
				left: r.left,
				width: r.width,
				height: r.height,
			});
			document.documentElement.style.overflow = "hidden";

			gsap.to(backdrop, {
				opacity: 1,
				duration: DUR,
				ease: "power2.out",
			});
			backdrop.style.pointerEvents = "auto";
			gsap.to(box, {
				top: 0,
				left: 0,
				width: window.innerWidth,
				height: window.innerHeight,
				duration: DUR,
				ease: EASE,
				onComplete: function () {
					busy = false;
					video.controls = true;
					video.play().catch(function () {});
				},
			});
		}

		function close() {
			if (!active || busy) {
				return;
			}
			busy = true;

			var a = active;
			a.video.pause();
			a.video.controls = false;

			// Where the placeholder is NOW (page may have moved/resized).
			var r = a.placeholder.getBoundingClientRect();

			gsap.to(backdrop, {
				opacity: 0,
				duration: DUR,
				ease: "power2.out",
			});
			gsap.to(a.box, {
				top: r.top,
				left: r.left,
				width: r.width,
				height: r.height,
				duration: DUR,
				ease: EASE,
				onComplete: function () {
					a.box.classList.remove("is-open");
					gsap.set(a.box, { clearProps: "top,left,width,height" });
					a.placeholder.parentNode.removeChild(a.placeholder);
					a.closeBtn.parentNode.removeChild(a.closeBtn);
					backdrop.style.pointerEvents = "none";
					document.documentElement.style.overflow = "";
					active = null;
					busy = false;
				},
			});
		}

		boxes.forEach(function (box) {
			box.addEventListener("click", function (e) {
				if (e.target.closest(".closeBtn")) {
					close();
					return;
				}
				if (!box.classList.contains("is-open")) {
					open(box);
				}
			});
		});

		backdrop.addEventListener("click", close);
		document.addEventListener("keydown", function (e) {
			if (e.key === "Escape") {
				close();
			}
		});

		// Keep it full-screen if the window is resized while open.
		window.addEventListener("resize", function () {
			if (active && !busy) {
				gsap.set(active.box, {
					top: 0,
					left: 0,
					width: window.innerWidth,
					height: window.innerHeight,
				});
			}
		});
	}

	if (document.readyState === "loading") {
		document.addEventListener("DOMContentLoaded", initVideoFullscreen);
	} else {
		initVideoFullscreen();
	}
})();

// Diagnosis Center section effect
(function () {
	"use strict";

	function initDiagnosisCenter() {
		var section = document.querySelector(".diagnosiscenterSection");
		if (
			!section ||
			typeof gsap === "undefined" ||
			typeof ScrollTrigger === "undefined"
		) {
			return;
		}
		if (window.matchMedia("(prefers-reduced-motion: reduce)").matches) {
			return;
		}

		gsap.registerPlugin(ScrollTrigger);

		/* ---------- 1. Image: scale in / out loop ---------- */
		var img = section.querySelector(".diagnosiscenterImg img");
		if (img) {
			var pulse = gsap.fromTo(
				img,
				{ scale: 0.92 },
				{
					scale: 1.06,
					duration: 2,
					ease: "sine.inOut",
					yoyo: true,
					repeat: -1,
					paused: true,
					transformOrigin: "50% 50%",
				},
			);
			// Only run the loop while the image is on screen.
			ScrollTrigger.create({
				trigger: img,
				start: "top bottom",
				end: "bottom top",
				onToggle: function (self) {
					self.isActive ? pulse.play() : pulse.pause();
				},
			});
		}

		/* ---------- 2. Heading line draws, then circle travels ---------- */
		var svg = section.querySelector(".secHeading > svg");
		if (!svg) {
			return;
		}

		var line = svg.querySelector(":scope > g"); // the dashed line
		var dot = svg.querySelector(":scope > path"); // the circle
		if (!line || !dot) {
			return;
		}

		svg.style.overflow = "visible"; // so the circle isn't clipped at the start

		// A mask whose width grows = the line "draws" left to right
		// (the line is dashed, so stroke-dashoffset can't be used).
		var NS = "http://www.w3.org/2000/svg";
		var defs =
			svg.querySelector("defs") ||
			svg.insertBefore(
				document.createElementNS(NS, "defs"),
				svg.firstChild,
			);
		var mask = document.createElementNS(NS, "mask");
		mask.setAttribute("id", "diagLineMask");
		mask.setAttribute("maskUnits", "userSpaceOnUse");
		mask.setAttribute("x", "0");
		mask.setAttribute("y", "0");
		mask.setAttribute("width", "669");
		mask.setAttribute("height", "25");
		var rect = document.createElementNS(NS, "rect");
		rect.setAttribute("x", "0");
		rect.setAttribute("y", "0");
		rect.setAttribute("width", "0");
		rect.setAttribute("height", "25");
		rect.setAttribute("fill", "#fff");
		mask.appendChild(rect);
		defs.appendChild(mask);
		line.setAttribute("mask", "url(#diagLineMask)");

		// Circle's resting centre is ~x137; start it at the line's left end.
		var CIRCLE_REST_X = 137;

		gsap.set(dot, { x: -CIRCLE_REST_X, autoAlpha: 0 });

		var tl = gsap.timeline({
			scrollTrigger: {
				trigger: svg,
				start: "top 85%",
				toggleActions: "restart none restart none",
			},
		});

		tl.to(rect, {
			attr: { width: 669 },
			duration: 2,
			ease: "power2.inOut",
		});
		tl.to(dot, { autoAlpha: 1, duration: 0.3, ease: "none" });
		tl.to(dot, { x: 0, duration: 1.4, ease: "power3.out" }, "<");
	}

	if (document.readyState === "complete") {
		initDiagnosisCenter();
	} else {
		window.addEventListener("load", initDiagnosisCenter);
	}
})();

if ($(".ourAiSection").length) {
	if (window.innerWidth <= 1080) {
		$(".aiImgSlider").slick({
			slidesToShow: 1,
			slidesToScroll: 1,
			arrows: false,
			fade: true,
			infinite: false,
			asNavFor: ".texBoxtSlider",
		});
		$(".aiTextSlider").slick({
			slidesToShow: 1,
			slidesToScroll: 1,
			arrows: true,
			prevArrow: $(".aiSecPrevArrow"),
			nextArrow: $(".aiSecNextArrow"),
			asNavFor: ".aiImgSlider",
			dots: false,
			fade: true,
			infinite: false,
			centerMode: false,
			focusOnSelect: false,
		});
	}
}

//Ai -Atlas Js
if ($(".agentSection").length) {
	$(".imgBoxes").slick({
		slidesToShow: 1,
		slidesToScroll: 1,
		arrows: false,
		fade: false,
		speed: 500,
		infinite: false,
		asNavFor: ".texBoxtSlider",
	});
	$(".texBoxtSlider").slick({
		slidesToShow: 1,
		slidesToScroll: 1,
		arrows: true,
		prevArrow: $(".studioPrevArrow"),
		nextArrow: $(".studioNextArrow"),
		asNavFor: ".imgBoxes",
		dots: false,
		fade: true,
		infinite: false,
		centerMode: false,
		focusOnSelect: false,
	});
}

// What Get Section
(function () {
	"use strict";

	function initWhatGetSequence() {
		var section = document.querySelector(".whatgetSection");
		if (
			!section ||
			typeof gsap === "undefined" ||
			typeof ScrollTrigger === "undefined"
		) {
			return;
		}
		if (window.matchMedia("(prefers-reduced-motion: reduce)").matches) {
			return;
		}

		gsap.registerPlugin(ScrollTrigger);

		var INCLUDE_BG = true; // .whatgetbg changes together with the image
		var FADE = 1.2; // how slowly the next image appears (higher = slower)
		var HOLD = 1; // how long each image stays fully visible
		var OUT = 0.1; // quick drop-out of the old image, after the new one is fully in

		var mm = gsap.matchMedia();

		// Runs only when the viewport is 720px or wider.
		mm.add("(min-width: 720px)", function () {
			var boxes = section.querySelectorAll(".whatgetBox");
			if (boxes.length < 2) {
				return;
			}

			var groups = [];
			boxes.forEach(function (box) {
				var g = [box.querySelector("img:not(.whatgetbg)")];
				if (INCLUDE_BG) {
					g.push(box.querySelector(".whatgetbg"));
				}
				g = g.filter(Boolean);
				if (g.length) {
					groups.push(g);
				}
			});
			var n = groups.length;
			if (n < 2) {
				return;
			}

			var all = [].concat.apply([], groups);
			gsap.set(all, { opacity: 0 });

			var STEP = HOLD + FADE;

			// Handover k: the next image fades in while the current one stays at full opacity,
			// then the current one drops out quickly. Nothing is ever dimmed in between.
			var tl = gsap.timeline({ repeat: -1, paused: true });
			for (var k = 1; k <= n; k++) {
				var from = groups[k - 1];
				var to = groups[k % n];
				var at = k * STEP - FADE;
				tl.to(
					to,
					{ opacity: 1, duration: FADE, ease: "sine.inOut" },
					at,
				);
				tl.to(
					from,
					{ opacity: 0, duration: OUT, ease: "none" },
					at + FADE,
				);
			}

			var started = false;
			ScrollTrigger.create({
				trigger: section,
				start: "top 80%",
				end: "bottom top",
				onToggle: function (self) {
					if (!self.isActive) {
						tl.pause();
						return;
					}
					if (!started) {
						started = true;
						// First image fades in slowly, then the loop takes over.
						gsap.to(groups[0], {
							opacity: 1,
							duration: FADE,
							ease: "sine.inOut",
							onComplete: function () {
								tl.play(0);
							},
						});
					} else {
						tl.play();
					}
				},
			});
		});
	}

	if (document.readyState === "complete") {
		initWhatGetSequence();
	} else {
		window.addEventListener("load", initWhatGetSequence);
	}
})();

document.addEventListener("DOMContentLoaded", () => {
	const containers = document.querySelectorAll(
		".whatgetSection .whatgetContent",
	);
	const mobileQuery = window.matchMedia("(max-width: 720px)"); // apne SCSS ke media query se match rakhna

	containers.forEach((container) => {
		const cards = [...container.querySelectorAll(".whatgetBox")];
		if (!cards.length) return;

		function openCard(activeCard) {
			cards.forEach((card) => {
				card.classList.toggle("activeCard", card === activeCard);
			});
		}

		function initializeAccordion() {
			if (mobileQuery.matches) {
				// Agar koi card pehle se active nahi hai to pehla open karo
				const activeCard = cards.find((card) =>
					card.classList.contains("activeCard"),
				);
				openCard(activeCard || cards[0]);
			} else {
				// Desktop par sab reset
				cards.forEach((card) => card.classList.remove("activeCard"));
			}
		}

		initializeAccordion();

		cards.forEach((card) => {
			card.addEventListener("click", (event) => {
				if (!mobileQuery.matches) return;
				if (event.target.closest("a, button")) return;

				if (card.classList.contains("activeCard")) {
					card.classList.remove("activeCard");
				} else {
					openCard(card);
				}
			});
		});

		if (mobileQuery.addEventListener) {
			mobileQuery.addEventListener("change", initializeAccordion);
		} else {
			mobileQuery.addListener(initializeAccordion); // old Safari
		}
	});
});

// How Run Animation
(function () {
	"use strict";

	function initHowRun() {
		var section = document.querySelector(".howrunSection");
		if (
			!section ||
			typeof gsap === "undefined" ||
			typeof ScrollTrigger === "undefined"
		) {
			return;
		}
		if (window.matchMedia("(prefers-reduced-motion: reduce)").matches) {
			return;
		}

		gsap.registerPlugin(ScrollTrigger);

		var img = section.querySelector(".howrunImg img");
		var svg = section.querySelector(".secHeading .lineanim");
		var line = svg ? svg.querySelector(":scope > g") : null;
		var heading = section.querySelector(".howrunContent .secHeading");

		var IMG_DISTANCE = 250; // px it rises from the bottom
		var IMG_TIME = 2; // image speed (higher = slower)
		var LINE_TIME = 2; // line draw speed
		var LINE_DELAY = 0.4; // line starts this long after the image starts

		/* Line draw: a mask that grows left to right (the line is dashed, so
		   stroke-dashoffset can't be used). */
		var rect = null;
		if (svg && line) {
			var NS = "http://www.w3.org/2000/svg";
			var defs =
				svg.querySelector("defs") ||
				svg.insertBefore(
					document.createElementNS(NS, "defs"),
					svg.firstChild,
				);
			var mask = document.createElementNS(NS, "mask");
			mask.setAttribute("id", "howrunLineMask");
			mask.setAttribute("maskUnits", "userSpaceOnUse");
			mask.setAttribute("x", "0");
			mask.setAttribute("y", "0");
			mask.setAttribute("width", "669");
			mask.setAttribute("height", "25");
			rect = document.createElementNS(NS, "rect");
			rect.setAttribute("x", "0");
			rect.setAttribute("y", "0");
			rect.setAttribute("width", "0");
			rect.setAttribute("height", "25");
			rect.setAttribute("fill", "#fff");
			mask.appendChild(rect);
			defs.appendChild(mask);
			line.setAttribute("mask", "url(#howrunLineMask)");
		}

		var tl = gsap.timeline({
			scrollTrigger: {
				trigger: section,
				start: "top 70%",
				toggleActions: "restart none restart none",
			},
		});

		if (img) {
			tl.fromTo(
				img,
				{ y: IMG_DISTANCE, autoAlpha: 0 },
				{ y: 0, autoAlpha: 1, duration: IMG_TIME, ease: "power2.out" },
				0,
			);
		}
		if (heading) {
			tl.fromTo(
				heading,
				{ x: IMG_DISTANCE, autoAlpha: 0 },
				{ x: 0, autoAlpha: 1, duration: IMG_TIME, ease: "power2.out" },
				0,
			);
		}
		if (rect) {
			tl.fromTo(
				rect,
				{ attr: { width: 0 } },
				{
					attr: { width: 669 },
					duration: LINE_TIME,
					ease: "power2.inOut",
				},
				LINE_DELAY,
			);
		}
	}

	if (document.readyState === "complete") {
		initHowRun();
	} else {
		window.addEventListener("load", initHowRun);
	}
})();

// Shared section behaviour.
// Markup opts in with data attributes; nothing runs where they are absent.
//
//   data-accordion            group of panels; one is open (class is-open). Opens on click.
//     data-autoplay="5000"    optional: step through panels until the visitor clicks one.
//     data-accordion-item     a panel (role=button, tabindex=0 recommended)
//     data-accordion-detail   optional detail block shown for the open panel, same order
//   data-toggle-group         rows or cards that open on click, one at a time
//     data-toggle-item / data-toggle (the button inside the item)
//   data-tabs                 data-tab buttons switch data-tab-panel blocks, same order
//   data-reveal               fades in when scrolled into view (class is-visible)
//   data-count="350"          number counts up when visible; keeps any prefix/suffix text
//   data-marquee              children scroll continuously; content is duplicated for a seamless loop
(function () {
	"use strict";

	var reduceMotion = window.matchMedia(
		"(prefers-reduced-motion: reduce)",
	).matches;

	function onVisible(el, callback, threshold) {
		if (!("IntersectionObserver" in window)) {
			callback(true);
			return;
		}
		new IntersectionObserver(
			function (entries) {
				entries.forEach(function (entry) {
					callback(entry.isIntersecting);
				});
			},
			{ threshold: threshold || 0.3 },
		).observe(el);
	}

	function accordions() {
		document.querySelectorAll("[data-accordion]").forEach(function (root) {
			var items = Array.prototype.slice.call(
				root.querySelectorAll("[data-accordion-item]"),
			);
			var details = Array.prototype.slice.call(
				root.querySelectorAll("[data-accordion-detail]"),
			);
			if (!items.length) return;

			var index = Math.max(
				0,
				items.findIndex(function (el) {
					return el.classList.contains("is-open");
				}),
			);
			var timer = null;
			var chosen = false;

			function show(next) {
				index = next;
				items.forEach(function (el, i) {
					el.classList.toggle("is-open", i === index);
					el.setAttribute("aria-expanded", String(i === index));
				});
				details.forEach(function (el, i) {
					el.classList.toggle("is-open", i === index);
				});
			}

			function choose(i) {
				chosen = true;
				clearInterval(timer);
				timer = null;
				show(i);
			}

			items.forEach(function (el, i) {
				el.addEventListener("click", function () {
					choose(i);
				});
				el.addEventListener("keydown", function (e) {
					if (e.key === "Enter" || e.key === " ") {
						e.preventDefault();
						choose(i);
					}
				});
			});
			show(index);

			var delay = parseInt(root.getAttribute("data-autoplay") || "0", 10);
			if (!delay || reduceMotion) return;
			onVisible(root, function (visible) {
				if (visible && !chosen && !timer) {
					timer = setInterval(function () {
						show((index + 1) % items.length);
					}, delay);
				} else if (!visible) {
					clearInterval(timer);
					timer = null;
				}
			});
		});
	}

	function toggleGroups() {
		document
			.querySelectorAll("[data-toggle-group]")
			.forEach(function (group) {
				var items = Array.prototype.slice.call(
					group.querySelectorAll("[data-toggle-item]"),
				);
				items.forEach(function (item) {
					var trigger = item.querySelector("[data-toggle]");
					if (!trigger) return;
					trigger.addEventListener("click", function () {
						var open = !item.classList.contains("is-open");
						items.forEach(function (other) {
							var isOpen = other === item && open;
							other.classList.toggle("is-open", isOpen);
							var t = other.querySelector("[data-toggle]");
							if (t)
								t.setAttribute("aria-expanded", String(isOpen));
						});
					});
				});
			});
	}

	function tabs() {
		document.querySelectorAll("[data-tabs]").forEach(function (root) {
			var buttons = Array.prototype.slice.call(
				root.querySelectorAll("[data-tab]"),
			);
			var panels = Array.prototype.slice.call(
				root.querySelectorAll("[data-tab-panel]"),
			);
			function show(i) {
				buttons.forEach(function (b, k) {
					b.classList.toggle("is-active", k === i);
					b.setAttribute("aria-selected", String(k === i));
				});
				panels.forEach(function (p, k) {
					p.classList.toggle("is-active", k === i);
					p.hidden = k !== i;
				});
			}
			buttons.forEach(function (b, i) {
				b.addEventListener("click", function () {
					show(i);
				});
			});
			if (buttons.length)
				show(
					Math.max(
						0,
						buttons.findIndex(function (b) {
							return b.classList.contains("is-active");
						}),
					),
				);
		});
	}

	function reveal() {
		var items = document.querySelectorAll("[data-reveal]");
		if (reduceMotion || !("IntersectionObserver" in window)) {
			items.forEach(function (el) {
				el.classList.add("is-visible");
			});
			return;
		}
		var io = new IntersectionObserver(
			function (entries) {
				entries.forEach(function (entry) {
					if (entry.isIntersecting) {
						entry.target.classList.add("is-visible");
						io.unobserve(entry.target);
					}
				});
			},
			{ rootMargin: "0px 0px -10% 0px", threshold: 0.1 },
		);
		items.forEach(function (el) {
			io.observe(el);
		});
	}

	function counters() {
		document.querySelectorAll("[data-count]").forEach(function (el) {
			var target = parseFloat(el.getAttribute("data-count"));
			var template = el.textContent;
			var digits = template.match(/[\d,.]+/);
			if (!digits || isNaN(target) || reduceMotion) return;
			var done = false;
			onVisible(
				el,
				function (visible) {
					if (!visible || done) return;
					done = true;
					var start = performance.now();
					(function step(now) {
						var t = Math.min(1, (now - start) / 1400);
						var value = Math.round(
							target * (1 - Math.pow(1 - t, 3)),
						);
						el.textContent = template.replace(
							digits[0],
							value.toLocaleString("en-US"),
						);
						if (t < 1) requestAnimationFrame(step);
					})(start);
				},
				0.5,
			);
		});
	}

	function marquees() {
		document.querySelectorAll("[data-marquee]").forEach(function (track) {
			if (track.dataset.marqueeReady) return;
			track.dataset.marqueeReady = "1";
			Array.prototype.slice
				.call(track.children)
				.forEach(function (child) {
					var copy = child.cloneNode(true);
					copy.setAttribute("aria-hidden", "true");
					track.appendChild(copy);
				});
		});
	}

	document.addEventListener("DOMContentLoaded", function () {
		accordions();
		toggleGroups();
		tabs();
		reveal();
		counters();
		marquees();
	});
})();

// Home page: typewriter on the AI Atlas chip, and impact story cards that
// open their description on click when they have no link.
(function () {
	"use strict";

	if (!document.body.classList.contains("page-template-hompage")) {
		return;
	}

	var reduceMotion = window.matchMedia(
		"(prefers-reduced-motion: reduce)",
	).matches;

	// AI Atlas chip: type the word, hold, erase, repeat while it is on screen.
	function typewriter(el) {
		var text = el.getAttribute("data-typewriter") || "";
		var typed = el.querySelector(".atlasChipTyped");
		if (!typed || !text || reduceMotion) {
			return;
		}
		var count = 0;
		var deleting = false;
		var timer = null;
		var running = false;

		function step() {
			typed.textContent = text.slice(0, count);
			var delay = deleting ? 70 : 140;
			if (!deleting && count === text.length) {
				deleting = true;
				delay = 2200;
			} else if (deleting && count === 0) {
				deleting = false;
				delay = 600;
			} else {
				count += deleting ? -1 : 1;
			}
			timer = setTimeout(step, delay);
		}

		function start() {
			if (running) return;
			running = true;
			count = 0;
			deleting = false;
			step();
		}

		function stop() {
			running = false;
			clearTimeout(timer);
			typed.textContent = text;
		}

		if ("IntersectionObserver" in window) {
			new IntersectionObserver(
				function (entries) {
					entries.forEach(function (entry) {
						if (entry.isIntersecting) {
							start();
						} else {
							stop();
						}
					});
				},
				{ threshold: 0.4 },
			).observe(el);
		} else {
			start();
		}
	}

	// Impact story cards without a link: click or Enter/Space shows the description.
	function impactCards() {
		document
			.querySelectorAll(".homeImpactSec .homeImpactCard:not([href])")
			.forEach(function (card) {
				function toggle() {
					var open = !card.classList.contains("is-open");
					card.classList.toggle("is-open", open);
					card.setAttribute("aria-expanded", open ? "true" : "false");
				}
				card.addEventListener("click", function (event) {
					event.preventDefault();
					toggle();
				});
				card.addEventListener("keydown", function (event) {
					if (event.key === "Enter" || event.key === " ") {
						event.preventDefault();
						toggle();
					}
				});
			});
	}

	function init() {
		document
			.querySelectorAll(".atlasChipText[data-typewriter]")
			.forEach(typewriter);
		impactCards();
	}

	if (document.readyState === "loading") {
		document.addEventListener("DOMContentLoaded", init);
	} else {
		init();
	}
})();

// Platform: the Customer Impact Story cards open their description on click
// (data-toggle-group, above). This adds the keyboard: Enter or Space on a focused card does the same.
(function () {
	"use strict";

	if (!document.body.classList.contains("page-template-platform")) return;

	document
		.querySelectorAll(".platformResultSec [data-toggle]")
		.forEach(function (box) {
			box.addEventListener("keydown", function (event) {
				if (event.key !== "Enter" && event.key !== " ") return;
				event.preventDefault();
				box.click();
			});
		});
})();

// AI Atlas page.
//
// Four Artifacts: a panel opens on click (or Enter / Space), never on hover, and the
// detail block under the panels follows the open panel. On wide screens the accordion above
// leaves the panels alone (its accordion only runs at 820px and below), so the open
// state is set here; at 820px and below that accordion opens and closes the panels and
// this script only keeps the detail block in step.
//
// Customer Impact Stories: a card shows its description on hover, or on click/tap.
// (function () {
// 	'use strict';

// 	if (!document.body.classList.contains('page-template-ai-atlas')) {
// 		return;
// 	}

// 	function artifacts() {
// 		var section = document.querySelector('.fourArtifactsSec');
// 		if (!section) return;

// 		var cards = Array.prototype.slice.call(section.querySelectorAll('.cardContainer .solutionCard'));
// 		var details = Array.prototype.slice.call(section.querySelectorAll('.artifactDetailBox .artifactDetail'));
// 		if (!cards.length) return;

// 		var mobile = window.matchMedia('(max-width: 820px)');
// 		// The template marks the panel open on load; the accordion above may already have removed
// 		// the class from the panel, but not from its detail block.
// 		var current = Math.max(0, details.findIndex(function (detail) {
// 			return detail.classList.contains('active');
// 		}));

// 		function showDetail(index) {
// 			details.forEach(function (detail, i) {
// 				var active = i === index;
// 				detail.classList.toggle('active', active);
// 				detail.hidden = !active;
// 			});
// 		}

// 		function syncAria() {
// 			cards.forEach(function (card) {
// 				card.setAttribute('aria-expanded', String(card.classList.contains('solutionActiveCard')));
// 			});
// 		}

// 		function open(index) {
// 			current = index;
// 			cards.forEach(function (card, i) {
// 				card.classList.toggle('solutionActiveCard', i === index);
// 			});
// 			syncAria();
// 			showDetail(index);
// 		}

// 		cards.forEach(function (card, i) {
// 			card.addEventListener('click', function () {
// 				if (mobile.matches) {
// 					// The accordion above has already opened or closed the panel.
// 					var openIndex = cards.findIndex(function (c) {
// 						return c.classList.contains('solutionActiveCard');
// 					});
// 					if (openIndex > -1) {
// 						current = openIndex;
// 						showDetail(openIndex);
// 					}
// 					syncAria();
// 					return;
// 				}
// 				open(i);
// 			});
// 			card.addEventListener('keydown', function (e) {
// 				if (e.key === 'Enter' || e.key === ' ') {
// 					e.preventDefault();
// 					card.click();
// 				}
// 			});
// 		});

// 		// The accordion above closes every panel on wide screens when it starts and when the
// 		// viewport crosses 820px; reopen the current one.
// 		if (!mobile.matches) {
// 			open(current);
// 		}
// 		mobile.addEventListener('change', function () {
// 			if (!mobile.matches) {
// 				open(current);
// 			} else {
// 				syncAria();
// 			}
// 		});
// 	}

// 	function impactCards() {
// 		var cards = document.querySelectorAll('.impactStoriesSec .resultCardSlider a');
// 		var canHover = window.matchMedia('(hover: hover)');

// 		Array.prototype.forEach.call(cards, function (card) {
// 			card.addEventListener('click', function (e) {
// 				var hasLink = card.hasAttribute('href');
// 				var isOpen = card.classList.contains('isOpen');
// 				// A linked card follows its link once its description is showing.
// 				if (hasLink && (isOpen || canHover.matches)) return;
// 				e.preventDefault();
// 				Array.prototype.forEach.call(cards, function (other) {
// 					if (other !== card) other.classList.remove('isOpen');
// 				});
// 				card.classList.toggle('isOpen', !isOpen);
// 			});
// 			card.addEventListener('keydown', function (e) {
// 				if (!card.hasAttribute('href') && (e.key === 'Enter' || e.key === ' ')) {
// 					e.preventDefault();
// 					card.click();
// 				}
// 			});
// 		});
// 	}

// 	function init() {
// 		artifacts();
// 		impactCards();
// 	}

// 	if (document.readyState === 'loading') {
// 		document.addEventListener('DOMContentLoaded', init);
// 	} else {
// 		init();
// 	}
// })();

/*
document.querySelectorAll(".fourArtifactsSec").forEach((section) => {
    const cards = section.querySelectorAll(".solutionCard");
    const details = section.querySelectorAll(".artifactDetail");

    cards.forEach((card) => {
        card.addEventListener("mouseenter", () => {
			if (window.matchMedia("(max-width: 820px)").matches) return;

            const panelNumber = card.dataset.panel;
			console.log(panelNumber);
			

            // Active card update
            cards.forEach((item) => {
                item.classList.remove("solutionActiveCard");
                item.setAttribute("aria-expanded", "false");
            });

            card.classList.add("solutionActiveCard");
            card.setAttribute("aria-expanded", "true");

            // Bottom details update
            details.forEach((detail) => {
                const isActive = detail.dataset.panel === panelNumber;

                detail.classList.toggle("active", isActive);
                detail.hidden = !isActive;
				if (isActive) {
					// Browser ko animation reset karne do
					void detail.offsetWidth;

					detail.classList.add("active");
				}
            });
        });
    });
});
*/

document.querySelectorAll(".fourArtifactsSec").forEach((section) => {
	const cards = section.querySelectorAll(".solutionCard");
	const details = section.querySelectorAll(".artifactDetail");

	// Common function: Update bottom details
	function updateDetails(panelNumber) {
		details.forEach((detail) => {
			const isActive = detail.dataset.panel === panelNumber;

			detail.classList.toggle("active", isActive);
			detail.hidden = !isActive;

			if (isActive) {
				void detail.offsetWidth;
				detail.classList.add("active");
			}
		});
	}

	// Desktop hover functionality
	cards.forEach((card) => {
		card.addEventListener("mouseenter", () => {
			if (window.matchMedia("(max-width: 820px)").matches) return;

			const panelNumber = card.dataset.panel;

			cards.forEach((item) => {
				item.classList.remove("solutionActiveCard");
				item.setAttribute("aria-expanded", "false");
			});

			card.classList.add("solutionActiveCard");
			card.setAttribute("aria-expanded", "true");

			updateDetails(panelNumber);
		});
	});

	// Mobile card open/close ke according details update
	cards.forEach((card) => {
		card.addEventListener("click", () => {
			if (!window.matchMedia("(max-width: 820px)").matches) return;

			requestAnimationFrame(() => {
				// Card open ho ya close, usi card ki details show rakho
				updateDetails(card.dataset.panel);
			});
		});
	});
});

// Greenfield consulting: a click on a Customer Impact Story card opens its description
// (hover still shows it on desktop). Cards without a link of their own do not reload the page.
(function () {
	"use strict";

	if (
		!document.body.classList.contains("page-template-greenfield-consulting")
	)
		return;

	var slider = document.querySelector(".gfImpactSec .platformResultSlider");
	if (!slider) return;

	var canHover = window.matchMedia("(hover: hover)");

	slider.addEventListener("click", function (event) {
		var card = event.target.closest("a");
		if (!card || !slider.contains(card)) return;

		var href = card.getAttribute("href");
		var box = card.querySelector(".box");
		if (!box || !box.querySelector(".moreContent")) return;

		var hasLink = href && href !== "#";
		// With a link: a mouse (which already shows the description on hover) follows it straight away;
		// on touch the first tap opens the description and the second follows the link.
		if (hasLink && (canHover.matches || box.classList.contains("is-open")))
			return;

		event.preventDefault();
		var open = !box.classList.contains("is-open");
		slider.querySelectorAll(".box.is-open").forEach(function (el) {
			el.classList.remove("is-open");
		});
		box.classList.toggle("is-open", open);
	});
})();

// Managed AI First Pods.
//
// - What you get: the first column is open from the start. The sequence earlier in this file
//   hides every image until the section scrolls into view; here the first column is shown again
//   right away, and the sequence then carries on from it as before.
// - Customer impact stories: the three cards fill the row on wide screens (the shared slider shows
//   2.8 to 3.5), and a click or tap on a card opens its description (hover still shows it on desktop).
(function () {
	"use strict";

	if (!document.body.classList.contains("page-template-managed-ai-pods")) {
		return;
	}

	function openFirstColumn() {
		var first = document.querySelector(".whatgetSection .whatgetBox");
		if (!first || window.innerWidth < 720) {
			return;
		}
		var parts = first.querySelectorAll(".iconImg, .whatgetbg");
		if (typeof gsap !== "undefined") {
			gsap.set(parts, { opacity: 1 });
		} else {
			parts.forEach(function (el) {
				el.style.opacity = "1";
			});
		}
	}

	// The theme's sequence starts on window load; run after it.
	if (document.readyState === "complete") {
		openFirstColumn();
	} else {
		window.addEventListener("load", function () {
			setTimeout(openFirstColumn, 0);
		});
	}

	function cardsToShow() {
		return window.innerWidth > 1024 ? 3 : null;
	}

	if (typeof jQuery !== "undefined") {
		jQuery(function ($) {
			var $slider = $(".mpodsImpactSec .platformResultSlider");
			if (!$slider.length || !$slider.hasClass("slick-initialized")) {
				return;
			}
			function fit() {
				var n = cardsToShow();
				if (n) {
					$slider.slick("slickSetOption", "slidesToShow", n, true);
				}
			}
			fit();
			// Registered after the theme's own resize handler, so this wins on wide screens.
			$(window).on("resize", fit);
		});
	}

	document
		.querySelectorAll(".mpodsImpactSec .resultCardSlider a:not([href])")
		.forEach(function (card) {
			function toggle() {
				var box = card.querySelector(".box");
				if (box) {
					box.classList.toggle("is-open");
					card.setAttribute(
						"aria-expanded",
						String(box.classList.contains("is-open")),
					);
				}
			}
			card.setAttribute("aria-expanded", "false");
			card.addEventListener("click", toggle);
			card.addEventListener("keydown", function (event) {
				if (event.key === "Enter" || event.key === " ") {
					event.preventDefault();
					toggle();
				}
			});
		});
})();

// Talos page: the Operations and governance cards.
// The row slides sideways (it is wider than the screen); a card opens on click or Enter/Space
// through the shared data-toggle-group behaviour above.
(function ($) {
	"use strict";

	document.addEventListener("DOMContentLoaded", function () {
		document
			.querySelectorAll(".talosOpsSec [data-toggle]")
			.forEach(function (trigger) {
				trigger.addEventListener("keydown", function (e) {
					if (e.key === "Enter" || e.key === " ") {
						e.preventDefault();
						trigger.click();
					}
				});
			});

		if (!$ || !$.fn || !$.fn.slick) return;
		$(".talosOpsSlider").slick({
			slidesToShow: 4.2,
			slidesToScroll: 1,
			arrows: false,
			dots: false,
			infinite: false,
			swipeToSlide: true,
			responsive: [
				{ breakpoint: 1281, settings: { slidesToShow: 3.2 } },
				{ breakpoint: 1025, settings: { slidesToShow: 2.6 } },
				{ breakpoint: 720, settings: { slidesToShow: 1.4 } },
			],
		});
	});
})(window.jQuery);

// AI Accelerators and Agents: the hero line drawing draws itself in, stroke by stroke.
// Uses Vivus (loaded in the footer); falls back to a CSS stroke-dashoffset transition.
(function () {
	"use strict";

	function start() {
		var box = document.querySelector(".aiaHeroDraw");
		var svg = box && box.querySelector("svg");
		if (!svg) return;

		function done() {
			box.classList.remove("is-pending");
		}

		if (window.matchMedia("(prefers-reduced-motion: reduce)").matches) {
			done();
			return;
		}

		if (typeof window.Vivus === "function") {
			new window.Vivus(
				svg,
				{
					type: "oneByOne",
					duration: 240,
					start: "autostart",
					animTimingFunction: window.Vivus.EASE_OUT,
				},
				function () {
					// Leave the finished drawing as plain strokes.
					svg.querySelectorAll("path").forEach(function (p) {
						p.style.strokeDasharray = "";
						p.style.strokeDashoffset = "";
					});
				},
			);
			done();
			return;
		}

		var paths = svg.querySelectorAll("path");
		paths.forEach(function (p, i) {
			var len = p.getTotalLength();
			p.style.strokeDasharray = len + " " + len;
			p.style.strokeDashoffset = len;
			p.style.transition =
				"stroke-dashoffset 1.2s ease-out " +
				((i / paths.length) * 2.8).toFixed(3) +
				"s";
		});
		done();
		requestAnimationFrame(function () {
			requestAnimationFrame(function () {
				paths.forEach(function (p) {
					p.style.strokeDashoffset = "0";
				});
			});
		});
	}

	if (document.readyState === "loading") {
		document.addEventListener("DOMContentLoaded", start);
	} else {
		start();
	}
})();

// Enterprise Truth Diagnosis and Enterprise Context Architects.
//
//   data-etd-timeline        hour-by-hour track. Steps through its items (data-etd-timeline-item)
//     data-autoplay="3500"   until the visitor clicks, focuses or swipes; the active item is kept in view.
//   .etdKeepCard             numbered cards opened by data-toggle-group (above). This file
//                            measures how far each panel must slide up to show its text, and lets
//                            the panel open from the keyboard.
(function () {
	"use strict";

	var reduceMotion = window.matchMedia(
		"(prefers-reduced-motion: reduce)",
	).matches;

	function timelines() {
		document
			.querySelectorAll("[data-etd-timeline]")
			.forEach(function (root) {
				var track = root.querySelector(".etdTimelineTrack");
				var items = Array.prototype.slice.call(
					root.querySelectorAll("[data-etd-timeline-item]"),
				);
				if (!track || !items.length) return;

				var index = Math.max(
					0,
					items.findIndex(function (el) {
						return el.classList.contains("is-active");
					}),
				);
				var timer = null;
				var chosen = false;
				var visible = false;

				function place() {
					var item = items[index];
					var last = items[items.length - 1];
					var max = Math.max(
						0,
						last.offsetLeft + last.offsetWidth - root.clientWidth,
					);
					var target =
						item.offsetLeft +
						item.offsetWidth / 2 -
						root.clientWidth / 2;
					var shift = Math.min(max, Math.max(0, target));
					track.style.transform = "translateX(" + -shift + "px)";
				}

				function show(next) {
					index = next;
					items.forEach(function (el, i) {
						el.classList.toggle("is-active", i === index);
						el.setAttribute("aria-pressed", String(i === index));
					});
					place();
				}

				function stop() {
					clearInterval(timer);
					timer = null;
				}

				function start() {
					var delay = parseInt(
						root.getAttribute("data-autoplay") || "0",
						10,
					);
					if (
						!delay ||
						reduceMotion ||
						chosen ||
						timer ||
						!visible ||
						items.length < 2
					)
						return;
					timer = setInterval(function () {
						show((index + 1) % items.length);
					}, delay);
				}

				function choose(i) {
					chosen = true;
					stop();
					show(i);
				}

				items.forEach(function (el, i) {
					el.addEventListener("click", function () {
						choose(i);
					});
					// Keyboard users tabbing to an item that is off to the side bring it into view.
					el.addEventListener("focus", function () {
						if (i !== index) choose(i);
					});
				});

				// Swipe left or right on touch screens to move one step.
				var startX = null;
				root.addEventListener(
					"touchstart",
					function (e) {
						startX = e.touches[0].clientX;
					},
					{ passive: true },
				);
				root.addEventListener("touchend", function (e) {
					if (startX === null) return;
					var dx = e.changedTouches[0].clientX - startX;
					startX = null;
					if (Math.abs(dx) < 40) return;
					choose(
						Math.min(
							items.length - 1,
							Math.max(0, index + (dx < 0 ? 1 : -1)),
						),
					);
				});

				if ("IntersectionObserver" in window) {
					new IntersectionObserver(
						function (entries) {
							entries.forEach(function (entry) {
								visible = entry.isIntersecting;
								if (visible) start();
								else stop();
							});
						},
						{ threshold: 0.4 },
					).observe(root);
				}

				window.addEventListener("resize", place);
				show(index);
			});
	}

	function keepCards() {
		var cards = Array.prototype.slice.call(
			document.querySelectorAll(".etdKeepCard"),
		);
		if (!cards.length) return;

		function measure() {
			cards.forEach(function (card) {
				var panel = card.querySelector(".etdKeepPanel");
				var body = card.querySelector(".panelBody");
				var text = body ? body.querySelector("p") : null;
				if (!panel || !body || !text) return;
				// Slide up until the description sits inside the card with the panel's bottom padding below it.
				var bottomPad =
					parseFloat(getComputedStyle(body).paddingBottom) || 24;
				var textBottom =
					panel.offsetTop +
					text.offsetTop +
					text.offsetHeight +
					bottomPad;
				var shift = Math.max(0, textBottom - card.clientHeight);
				card.style.setProperty("--etd-shift", shift + "px");
			});
		}

		cards.forEach(function (card) {
			var trigger = card.querySelector('[data-toggle][role="button"]');
			if (!trigger) return;
			trigger.addEventListener("keydown", function (e) {
				if (e.key === "Enter" || e.key === " ") {
					e.preventDefault();
					trigger.click();
				}
			});
		});

		measure();
		window.addEventListener("resize", measure);
		window.addEventListener("load", measure);
	}

	document.addEventListener("DOMContentLoaded", function () {
		timelines();
		keepCards();
	});
})();

// Case Studies listing: filter chips (one choice per row, rows combine) and
// "Show more" paging. Runs only where [data-case-studies] is present.
(function () {
	"use strict";

	function init(root) {
		var perPage = parseInt(root.getAttribute("data-per-page") || "9", 10);
		var featuredStory = root.querySelector(".featuredStory");
		var cards = Array.prototype.slice.call(
			root.querySelectorAll("[data-case-card]"),
		);
		var rows = Array.prototype.slice.call(
			root.querySelectorAll("[data-filter-group]"),
		);
		var countEl = root.querySelector("[data-count-text]");
		var more = root.querySelector(".csMore");
		var moreButton = root.querySelector("[data-show-more]");
		var empty = root.querySelector(".csEmpty");
		var active = {};
		var limit = perPage;

		function values(card, group) {
			try {
				return JSON.parse(
					card.getAttribute("data-" + group.replace(/_/g, "-")) ||
						"[]",
				);
			} catch (e) {
				return [];
			}
		}

		function matches(card) {
			return Object.keys(active).every(function (group) {
				return (
					!active[group] ||
					values(card, group).indexOf(active[group]) !== -1
				);
			});
		}

		function render() {
			var matching = cards.filter(matches);
			// Show featured story only when all filters are selected as All
			var hasActiveFilter = Object.keys(active).some(function (group) {
				return active[group] !== "";
			});

			if (featuredStory) {
				featuredStory.hidden = hasActiveFilter;
			}
			cards.forEach(function (card) {
				card.classList.add("is-hidden");
			});
			matching.slice(0, limit).forEach(function (card) {
				card.classList.remove("is-hidden");
			});
			var shown = Math.min(limit, matching.length);
			if (countEl) {
				countEl.textContent = countEl
					.getAttribute("data-count-text")
					.replace("%1$s", shown)
					.replace("%2$s", matching.length);
			}
			if (more) more.hidden = matching.length <= limit;
			if (empty) empty.hidden = matching.length > 0;
		}

		rows.forEach(function (row) {
			var group = row.getAttribute("data-filter-group");
			var chips = Array.prototype.slice.call(
				row.querySelectorAll("[data-filter-value]"),
			);
			active[group] = "";
			chips.forEach(function (chip) {
				chip.addEventListener("click", function () {
					active[group] = chip.getAttribute("data-filter-value");
					chips.forEach(function (other) {
						var on = other === chip;
						other.classList.toggle("is-active", on);
						other.setAttribute("aria-pressed", String(on));
					});
					limit = perPage;
					render();
				});
			});
		});

		if (moreButton) {
			moreButton.addEventListener("click", function () {
				limit += perPage;
				render();
			});
		}

		render();
	}

	document.addEventListener("DOMContentLoaded", function () {
		document.querySelectorAll("[data-case-studies]").forEach(init);
	});
})();

// Case study detail: the "On this page" list highlights the section in view
// and scrolls smoothly to a section when clicked. Runs only where
// [data-case-toc] is present.
(function () {
	"use strict";

	function init(nav) {
		var links = Array.prototype.slice.call(
			nav.querySelectorAll('a[href^="#"]'),
		);
		var targets = links.map(function (link) {
			return document.getElementById(link.getAttribute("href").slice(1));
		});
		var reduceMotion = window.matchMedia(
			"(prefers-reduced-motion: reduce)",
		).matches;
		var ticking = false;

		function setActive(index) {
			links.forEach(function (link, i) {
				link.classList.toggle("is-active", i === index);
				if (i === index) {
					link.setAttribute("aria-current", "true");
				} else {
					link.removeAttribute("aria-current");
				}
			});
		}

		function update() {
			ticking = false;
			var line = window.innerHeight * 0.35;
			var index = 0;
			targets.forEach(function (target, i) {
				if (target && target.getBoundingClientRect().top <= line)
					index = i;
			});
			setActive(index);
		}

		links.forEach(function (link, i) {
			link.addEventListener("click", function (e) {
				var target = targets[i];
				if (!target) return;
				e.preventDefault();
				target.scrollIntoView({
					behavior: reduceMotion ? "auto" : "smooth",
					block: "start",
				});
				if (history.replaceState)
					history.replaceState(null, "", "#" + target.id);
				setActive(i);
			});
		});

		window.addEventListener(
			"scroll",
			function () {
				if (!ticking) {
					ticking = true;
					window.requestAnimationFrame(update);
				}
			},
			{ passive: true },
		);
		update();
	}

	document.addEventListener("DOMContentLoaded", function () {
		document.querySelectorAll("[data-case-toc]").forEach(init);
	});
})();

// Impact Slider
$(document).ready(function () {
	const $slider = $(".impactStoriesSlider");
	const $arrowBox = $(".platformResultPrevArrow").parent();

	function getSlides() {
		const w = window.innerWidth;
		if (w <= 720) return 1.2;
		if (w <= 1024) return 2;
		return 3;
	}

	$slider.on("init reInit breakpoint setPosition", function (e, slick) {
		$arrowBox.toggleClass(
			"noArrows",
			slick.slideCount <= slick.options.slidesToShow,
		);
	});

	$slider.slick({
		slidesToShow: getSlides(),
		slidesToScroll: 1,
		infinite: false,
		arrows: true,
		prevArrow: $(".platformResultPrevArrow"),
		nextArrow: $(".platformResultNextArrow"),
	});

	$(window).on("resize", function () {
		$slider.slick("slickSetOption", "slidesToShow", getSlides(), true);
	});
});

//Workforce Page JS
$(document).ready(function () {
	const $slider = $(".WorkforceResultSlider");

	function getSlides() {
		const w = window.innerWidth;
		if (w <= 720) return 1.1;
		if (w <= 1024) return 1.5;
		if (w <= 1280) return 2;
		return 3;
	}

	$slider.slick({
		slidesToShow: getSlides(),
		slidesToScroll: 1,
		infinite: false,
		autoplay: true,
		autoplaySpeed: 3000,
		speed: 1000,
		cssEase: "ease",
		arrows: true,
		prevArrow: $(".platformResultPrevArrow"),
		nextArrow: $(".platformResultNextArrow"),
	});

	$(window).on("resize", function () {
		$slider.slick("slickSetOption", "slidesToShow", getSlides(), true);
	});
});

if ($(".howItRunsSec").length) {
	if (window.innerWidth <= 720) {
		$(".cardSlider").slick({
			slidesToShow: 1,
			slidesToScroll: 1,
			arrows: true,
			prevArrow: $(".howItRunsPrevArrow"),
			nextArrow: $(".howItRunsNextArrow"),
			infinite: false,
			centerMode: false,
			focusOnSelect: false,
		});
	}
}

// Ai-Accelerators and agent

document.querySelectorAll(".projectTabsSection").forEach((section) => {
	const tabs = section.querySelectorAll(".tabBtn");
	const panels = section.querySelectorAll(".tabPanel");

	tabs.forEach((tab) => {
		tab.addEventListener("click", () => {
			const index = tab.dataset.tab;

			tabs.forEach((item) => item.classList.remove("active"));
			panels.forEach((panel) => panel.classList.remove("active"));

			tab.classList.add("active");

			const activePanel = section.querySelector(
				`.tabPanel[data-panel="${index}"]`,
			);

			if (activePanel) {
				activePanel.classList.add("active");
			}
		});
	});
});

if ($(".projectTabsSection").length) {
	if (window.innerWidth <= 820) {
		$(".tabSlider").slick({
			slidesToShow: 5.2,
			slidesToScroll: 1,
			arrows: false,
			infinite: false,
			centerMode: false,
			focusOnSelect: false,
			responsive: [
				{
					breakpoint: 721,
					settings: {
						slidesToShow: 2.5,
						slidesToScroll: 1,
					},
				},
			],
		});
	}
}

if ($(".aboutAwardsSec").length) {
	$(".marqueeGroup").slick({
		dots: false,
		infinite: true,
		arrows: false,
		slidesToShow: 3.8,
		slidesToScroll: 1,
		speed: 8000,
		autoplay: true,
		autoplaySpeed: 0,
		cssEase: "linear",
		pauseOnHover: true,
		responsive: [
			{
				breakpoint: 1281,
				settings: {
					slidesToShow: 3,
					slidesToScroll: 1,
					infinite: true,
				},
			},
			{
				breakpoint: 1081,
				settings: {
					slidesToShow: 2.5,
					slidesToScroll: 1,
					infinite: true,
				},
			},
			{
				breakpoint: 600,
				settings: {
					slidesToShow: 1.2,
					slidesToScroll: 1,
				},
			},
		],
	});
}

document.addEventListener("DOMContentLoaded", () => {
	const teamTabs = document.querySelectorAll("[data-team-tab]");

	const teamSections = [
		document.querySelector(".aboutTeamSec"),
		document.querySelector(".boardSection"),
		document.querySelector(".backedBySection"),
	];

	teamTabs.forEach((tab, index) => {
		tab.addEventListener("click", function () {
			// Active tab
			teamTabs.forEach((item) => item.classList.remove("is-active"));
			this.classList.add("is-active");

			// Scroll to respective section
			const targetSection = teamSections[index];

			if (targetSection) {
				const headerOffset = 100;

				const targetPosition =
					targetSection.getBoundingClientRect().top +
					window.scrollY -
					headerOffset;

				window.scrollTo({
					top: targetPosition,
					behavior: "smooth",
				});
			}
		});
	});
});

if ($(".aboutNewsSec").length) {
	$(".investorSlider").slick({
		dots: false,
		infinite: false,
		arrows: false,
		slidesToShow: 3.1,
		slidesToScroll: 1,
		responsive: [
			{
				breakpoint: 1081,
				settings: {
					slidesToShow: 3,
					slidesToScroll: 1,
				},
			},
			{
				breakpoint: 721,
				settings: {
					slidesToShow: 1.2,
					slidesToScroll: 1,
					dots: true,
				},
			},
		],
	});
}

// About us: "Where we are". The dashed dividers between offices draw in once the section scrolls into view.
(function () {
	"use strict";

	document.addEventListener("DOMContentLoaded", function () {
		var sec = document.querySelector(".aboutOfficesSec");
		if (!sec) return;
		if (
			window.matchMedia("(prefers-reduced-motion: reduce)").matches ||
			!("IntersectionObserver" in window)
		)
			return;

		sec.classList.add("js-reveal");
		var io = new IntersectionObserver(
			function (entries) {
				entries.forEach(function (e) {
					if (!e.isIntersecting) return;
					sec.classList.add("is-in");
					io.disconnect();
				});
			},
			{ threshold: 0.25 },
		);
		io.observe(sec);
	});
})();

// About us: "The first ten years" timeline.
// Desktop (>1100px): the section pins and the years move with the scroll (GSAP ScrollTrigger, already in the theme).
// Tablet and mobile (<=1100px): no pinning. The section keeps its natural height and the years are a swipeable strip.
// Year tabs work in both modes.
// (function () {
// 	"use strict";
// 	document.addEventListener("DOMContentLoaded", function () {
// 		var sec = document.querySelector(".aboutDecadeSec");
// 		if (!sec) return;

// 		var tabs = Array.prototype.slice.call(sec.querySelectorAll(".yearTab"));
// 		var items = Array.prototype.slice.call(
// 			sec.querySelectorAll(".decadeItem"),
// 		);
// 		var view = sec.querySelector(".decadeViewport");
// 		var track = sec.querySelector(".decadeTrack");
// 		var stage = sec.querySelector(".decadeStage");
// 		var N = items.length;
// 		if (!N || !view || !track || !stage) return;

// 		var reduce = window.matchMedia(
// 			"(prefers-reduced-motion: reduce)",
// 		).matches;
// 		var active = -1;
// 		var st = null; // the ScrollTrigger, only while pinned
// 		var lockUntil = 0; // ignore strip scroll events right after a tab click
// 		var readyTimer = 0;

// 		function setActive(i) {
// 			i = Math.max(0, Math.min(N - 1, i));
// 			if (i === active) return;
// 			if (active !== -1) showDots();
// 			active = i;
// 			items.forEach(function (el, k) {
// 				el.classList.toggle("is-active", k === i);
// 			});
// 			tabs.forEach(function (t, k) {
// 				t.classList.toggle("is-active", k === i);
// 				if (k === i) t.setAttribute("aria-current", "true");
// 				else t.removeAttribute("aria-current");
// 			});
// 			// Keep the active tab in view when the tab row scrolls (small screens).
// 			var box = tabs[i] && tabs[i].parentNode;
// 			if (box && box.scrollWidth > box.clientWidth) {
// 				box.scrollTo({
// 					left:
// 						tabs[i].offsetLeft -
// 						(box.clientWidth - tabs[i].offsetWidth) / 2,
// 					behavior: reduce ? "auto" : "smooth",
// 				});
// 			}
// 		}
// 		function showDots() {
// 			window.clearTimeout(readyTimer);
// 			sec.classList.add("is-ready");
// 		}

// 		function stepWidth() {
// 			return N > 1
// 				? items[1].offsetLeft - items[0].offsetLeft
// 				: items[0].offsetWidth;
// 		}

// 		function goTo(i) {
// 			setActive(i);
// 			if (st) {
// 				var y = st.start + (i / (N - 1)) * (st.end - st.start);
// 				window.scrollTo({
// 					top: y,
// 					behavior: reduce ? "auto" : "smooth",
// 				});
// 				return;
// 			}
// 			lockUntil = Date.now() + 800;
// 			view.scrollTo({
// 				left: i * stepWidth(),
// 				behavior: reduce ? "auto" : "smooth",
// 			});
// 		}

// 		tabs.forEach(function (t, i) {
// 			t.addEventListener("click", function () {
// 				goTo(i);
// 			});
// 		});

// 		// Strip (not pinned): the scroll position decides the active year.
// 		var ticking = false;
// 		view.addEventListener(
// 			"scroll",
// 			function () {
// 				if (
// 					st ||
// 					sec.classList.contains("is-pinned") ||
// 					Date.now() < lockUntil ||
// 					ticking
// 				)
// 					return;
// 				ticking = true;
// 				window.requestAnimationFrame(function () {
// 					ticking = false;
// 					var max = view.scrollWidth - view.clientWidth;
// 					var idx =
// 						view.scrollLeft >= max - 2
// 							? N - 1
// 							: Math.round(view.scrollLeft / stepWidth());
// 					setActive(idx);
// 				});
// 			},
// 			{ passive: true },
// 		);

// 		// Pinned, scroll-driven mode.
// 		if (window.gsap && window.ScrollTrigger && !reduce) {
// 			window.gsap.registerPlugin(window.ScrollTrigger);
// 			window.gsap.matchMedia().add("(min-width: 1101px)", function () {
// 				sec.classList.add("is-pinned");
// 				var perYear = function () {
// 					return Math.round(window.innerHeight * 0.5);
// 				};
// 				var tween = window.gsap.to(track, {
// 					x: function () {
// 						return -(N - 1) * stepWidth();
// 					},
// 					ease: "none",
// 					scrollTrigger: {
// 						trigger: sec,
// 						// If the section is taller than the screen, pin it by its bottom edge so nothing is cut.
// 						start: function () {
// 							return sec.offsetHeight > window.innerHeight
// 								? "bottom bottom"
// 								: "top top";
// 						},
// 						end: function () {
// 							return "+=" + (N - 1) * perYear();
// 						},
// 						pin: true,
// 						anticipatePin: 1,
// 						scrub: 0.6,
// 						invalidateOnRefresh: true,
// 						snap: {
// 							snapTo: 1 / (N - 1),
// 							duration: { min: 0.2, max: 0.5 },
// 							ease: "power2.out",
// 						},
// 						onUpdate: function (self) {
// 							setActive(Math.round(self.progress * (N - 1)));
// 						},
// 					},
// 				});
// 				st = tween.scrollTrigger;
// 				return function () {
// 					sec.classList.remove("is-pinned");
// 					st = null;
// 					window.gsap.set(track, { clearProps: "transform" });
// 				};
// 			});
// 		}

// 		// Intro: line draws, then the dot pops. Plays once.
// 		setActive(0);
// 		if (reduce || !("IntersectionObserver" in window)) return;
// 		sec.classList.add("js-reveal");
// 		var io = new IntersectionObserver(
// 			function (entries) {
// 				if (!entries[0].isIntersecting) return;
// 				sec.classList.add("is-in");
// 				readyTimer = window.setTimeout(showDots, 2400);
// 				io.disconnect();
// 			},
// 			{ threshold: 0.3 },
// 		);
// 		io.observe(stage);
// 	});
// })();

(function () {
	"use strict";
	document.addEventListener("DOMContentLoaded", function () {
		var sec = document.querySelector(".aboutDecadeSec");
		if (!sec) return;

		var tabs = Array.prototype.slice.call(sec.querySelectorAll(".yearTab"));
		var items = Array.prototype.slice.call(
			sec.querySelectorAll(".decadeItem"),
		);
		var view = sec.querySelector(".decadeViewport");
		var track = sec.querySelector(".decadeTrack");
		var stage = sec.querySelector(".decadeStage");
		var line = sec.querySelector(".decadeLine");
		var N = items.length;
		if (!N || !view || !track || !stage) return;

		var reduce = window.matchMedia(
			"(prefers-reduced-motion: reduce)",
		).matches;
		var active = -1;
		var st = null; // the ScrollTrigger, only while pinned
		var lockUntil = 0; // ignore strip scroll events while a tab click is still scrolling
		var lockTarget = 0; // where that scroll is heading
		var readyTimer = 0;

		function setActive(i) {
			i = Math.max(0, Math.min(N - 1, i));
			if (i === active) return;
			if (active !== -1) showDots();
			active = i;
			items.forEach(function (el, k) {
				el.classList.toggle("is-active", k === i);
			});
			tabs.forEach(function (t, k) {
				t.classList.toggle("is-active", k === i);
				if (k === i) t.setAttribute("aria-current", "true");
				else t.removeAttribute("aria-current");
			});
			// Keep the active tab in view when the tab row scrolls (small screens).
			var box = tabs[i] && tabs[i].parentNode;
			if (box && box.scrollWidth > box.clientWidth) {
				box.scrollTo({
					left:
						tabs[i].offsetLeft -
						(box.clientWidth - tabs[i].offsetWidth) / 2,
					behavior: reduce ? "auto" : "smooth",
				});
			}
		}
		function showDots() {
			window.clearTimeout(readyTimer);
			sec.classList.add("is-ready");
		}

		function stepWidth() {
			return N > 1
				? items[1].offsetLeft - items[0].offsetLeft
				: items[0].offsetWidth;
		}

		// Strip mode: real position of a card inside the scrolling content, and where the snapped card sits (scroll-padding).
		function itemX(i) {
			return (
				items[i].getBoundingClientRect().left -
				view.getBoundingClientRect().left +
				view.scrollLeft
			);
		}
		function snapPad() {
			return (
				parseFloat(window.getComputedStyle(view).scrollPaddingLeft) || 0
			);
		}

		// Desktop: once the first card moves left of the line's start, the line grows with it and reaches left: 0 with the card.
		var lineBase = 0;
		var lineW = 0;
		function syncLine() {
			if (!line) return;
			if (window.innerWidth <= 1100) {
				line.style.left = "";
				line.style.backgroundPositionX = "";
				return;
			}
			var box = stage.getBoundingClientRect();
			if (box.width !== lineW) {
				// read the start the stylesheet gives the line (left: 30.5%)
				lineW = box.width;
				line.style.left = "";
				lineBase = line.offsetLeft;
			}
			var left = Math.max(
				0,
				Math.min(
					lineBase,
					items[0].getBoundingClientRect().left - box.left,
				),
			);
			line.style.left = left + "px";
			line.style.backgroundPositionX = lineBase - left + "px"; // keeps the dots from sliding
		}

		// Strip mode: which year the scroll position points at.
		function stripIndex() {
			var max = view.scrollWidth - view.clientWidth;
			if (view.scrollLeft >= max - 2) return N - 1; // the end is always the last year
			var pad = snapPad();
			var reach = 0; // last card that can still be scrolled to the left edge
			items.forEach(function (el, k) {
				if (itemX(k) - pad <= max + 1) reach = k;
			});
			var from = itemX(reach) - pad;
			if (reach < N - 1 && view.scrollLeft > from) {
				// last stretch: spread the remaining cards over it so none is skipped
				return (
					reach +
					Math.round(
						((view.scrollLeft - from) / (max - from)) *
							(N - 1 - reach),
					)
				);
			}
			var idx = 0;
			var best = Infinity;
			items.forEach(function (el, k) {
				var dist = Math.abs(itemX(k) - pad - view.scrollLeft);
				if (dist < best) {
					best = dist;
					idx = k;
				}
			});
			return idx;
		}

		function goTo(i) {
			setActive(i);
			if (st) {
				var y = st.start + (i / (N - 1)) * (st.end - st.start);
				window.scrollTo({
					top: y,
					behavior: reduce ? "auto" : "smooth",
				});
				return;
			}
			var target = Math.max(
				0,
				Math.min(
					view.scrollWidth - view.clientWidth,
					itemX(i) - snapPad(),
				),
			);
			// the strip cannot scroll past its end, so the last few cards never reach the left edge: keep the clicked year active
			lockTarget = target;
			lockUntil =
				Math.abs(view.scrollLeft - target) > 2 ? Date.now() + 1500 : 0;
			view.scrollTo({
				left: target,
				behavior: reduce ? "auto" : "smooth",
			});
		}

		tabs.forEach(function (t, i) {
			t.addEventListener("click", function () {
				goTo(i);
			});
		});

		// Strip (not pinned): the scroll position decides the active year.
		var ticking = false;
		view.addEventListener(
			"scroll",
			function () {
				syncLine();
				if (st || sec.classList.contains("is-pinned") || ticking)
					return;
				if (Date.now() < lockUntil) {
					// a tab click is still scrolling; the clicked year is already active
					if (Math.abs(view.scrollLeft - lockTarget) <= 2)
						lockUntil = Date.now() + 150; // arrived: let the last events pass
					return;
				}
				ticking = true;
				window.requestAnimationFrame(function () {
					ticking = false;
					setActive(stripIndex());
				});
			},
			{ passive: true },
		);

		// Pinned, scroll-driven mode.
		if (window.gsap && window.ScrollTrigger && !reduce) {
			window.gsap.registerPlugin(window.ScrollTrigger);
			window.gsap.matchMedia().add("(min-width: 1101px)", function () {
				sec.classList.add("is-pinned");
				var perYear = function () {
					return Math.round(window.innerHeight * 0.5);
				};
				var tween = window.gsap.to(track, {
					x: function () {
						return -(N - 1) * stepWidth();
					},
					ease: "none",
					onUpdate: syncLine,
					scrollTrigger: {
						trigger: sec,
						// If the section is taller than the screen, pin it by its bottom edge so nothing is cut.
						start: function () {
							return sec.offsetHeight > window.innerHeight
								? "bottom bottom"
								: "top top";
						},
						end: function () {
							return "+=" + (N - 1) * perYear();
						},
						pin: true,
						anticipatePin: 1,
						scrub: 0.6,
						invalidateOnRefresh: true,
						onRefresh: syncLine,
						snap: {
							snapTo: 1 / (N - 1),
							duration: { min: 0.2, max: 0.5 },
							ease: "power2.out",
						},
						onUpdate: function (self) {
							setActive(Math.round(self.progress * (N - 1)));
						},
					},
				});
				st = tween.scrollTrigger;
				return function () {
					sec.classList.remove("is-pinned");
					st = null;
					window.gsap.set(track, { clearProps: "transform" });
					syncLine();
				};
			});
		}

		window.addEventListener("resize", syncLine);

		// Intro: line draws, then the dot pops. Plays once.
		setActive(0);
		syncLine();
		if (reduce || !("IntersectionObserver" in window)) return;
		sec.classList.add("js-reveal");
		var io = new IntersectionObserver(
			function (entries) {
				if (!entries[0].isIntersecting) return;
				sec.classList.add("is-in");
				readyTimer = window.setTimeout(showDots, 2400);
				io.disconnect();
			},
			{ threshold: 0.3 },
		);
		io.observe(stage);
	});
})();

// ECA page: "Why can't my existing team do this?" role tabs.
(function () {
	"use strict";

	document.addEventListener("DOMContentLoaded", function () {
		var sec = document.querySelector(".ecaRolesSec");
		if (!sec) return;
		var tabs = Array.prototype.slice.call(
			sec.querySelectorAll(".rolesTab"),
		);
		var panels = Array.prototype.slice.call(
			sec.querySelectorAll(".rolesPanel"),
		);

		function select(i, focus) {
			tabs.forEach(function (t, k) {
				var on = k === i;
				t.classList.toggle("is-active", on);
				t.setAttribute("aria-selected", on ? "true" : "false");
				t.setAttribute("tabindex", on ? "0" : "-1");
			});
			panels.forEach(function (p, k) {
				p.classList.toggle("is-active", k === i);
			});
			if (focus) tabs[i].focus();
		}

		tabs.forEach(function (t, i) {
			t.addEventListener("click", function () {
				select(i);
			});
			t.addEventListener("keydown", function (e) {
				var n = tabs.length,
					next = -1;
				if (e.key === "ArrowRight" || e.key === "ArrowDown")
					next = (i + 1) % n;
				else if (e.key === "ArrowLeft" || e.key === "ArrowUp")
					next = (i - 1 + n) % n;
				else if (e.key === "Home") next = 0;
				else if (e.key === "End") next = n - 1;
				if (next < 0) return;
				e.preventDefault();
				select(next, true);
			});
		});
	});
})();

// ECA Video Section
// ECA page: "Hear from our Enterprise Context Architects" video popup.
// Works with YouTube/Vimeo embed URLs (iframe) or direct .mp4/.webm files (video tag).
(function () {
	"use strict";

	document.addEventListener("DOMContentLoaded", function () {
		var buttons = document.querySelectorAll(".ecaVoicesSec .voicePlay, .acceleratorworkSec .voicePlay");
		if (!buttons.length) return;

		var modal = document.createElement("div");
		modal.className = "ecaVideoModal";
		modal.setAttribute("role", "dialog");
		modal.setAttribute("aria-modal", "true");
		modal.setAttribute("aria-label", "Video");
		modal.innerHTML =
			'<div class="modalBox">' +
			'<button class="modalClose" type="button" aria-label="Close video"><svg viewBox="0 0 16 16" fill="none" stroke="currentColor" stroke-width="1.6" stroke-linecap="round" aria-hidden="true"><path d="M2 2l12 12M14 2 2 14"/></svg></button>' +
			'<div class="modalMedia"></div>' +
			"</div>";
		document.body.appendChild(modal);

		var media = modal.querySelector(".modalMedia");
		var closeBtn = modal.querySelector(".modalClose");
		var opener = null;

		function build(url) {
			var el;
			if (/\.(mp4|webm|ogg)(\?.*)?$/i.test(url)) {
				el = document.createElement("video");
				el.src = url;
				el.controls = true;
				el.autoplay = true;
				el.setAttribute("playsinline", "");
			} else {
				el = document.createElement("iframe");
				el.src =
					url + (url.indexOf("?") > -1 ? "&" : "?") + "autoplay=1";
				el.allow = "autoplay; fullscreen; picture-in-picture";
				el.allowFullscreen = true;
				el.title = "Video";
			}
			return el;
		}

		function open(btn) {
			var url = btn.getAttribute("data-video");
			if (!url) return;
			opener = btn;
			media.innerHTML = "";
			media.appendChild(build(url));
			modal.classList.add("is-open");
			document.body.classList.add("modalOpen");
			closeBtn.focus();
		}

		function close() {
			modal.classList.remove("is-open");
			document.body.classList.remove("modalOpen");
			media.innerHTML = ""; // removes the player, which also stops playback
			if (opener) opener.focus();
		}

		Array.prototype.forEach.call(buttons, function (btn) {
			btn.addEventListener("click", function () {
				open(btn);
			});
		});
		closeBtn.addEventListener("click", close);
		modal.addEventListener("click", function (e) {
			if (e.target === modal) close();
		});
		document.addEventListener("keydown", function (e) {
			if (!modal.classList.contains("is-open")) return;
			if (e.key === "Escape") close();
			if (e.key === "Tab") {
				// keep focus inside the popup
				var focusables = modal.querySelectorAll(
					"button, video[controls], iframe",
				);
				var first = focusables[0],
					last = focusables[focusables.length - 1];
				if (e.shiftKey && document.activeElement === first) {
					e.preventDefault();
					last.focus();
				} else if (!e.shiftKey && document.activeElement === last) {
					e.preventDefault();
					first.focus();
				}
			}
		});
	});
})();

// About us: "The leaders behind the journey". "Read the letter" opens a drawer that slides in from the right.
if ($(".aboutLeadersSec").length) {
	document.addEventListener("DOMContentLoaded", function () {
		// Select all the elements for cards (".imgBox") and modals (".teamDetailPopup")
		const elements = document.querySelectorAll(".leaderCard"); // Select all card elements
		const closeButtons = document.querySelectorAll(".drawerClose"); // Select all close buttons
		const body = document.querySelector("body");
		const html = document.querySelector("html");
		// Add click event listeners to each card
		elements.forEach((element) => {
			element.addEventListener("click", function () {
				// Replace the card id to find the corresponding modal (dynamically)
				const panelId = this.id.replace("leaderCard", "founder");
				const modal = document.getElementById(panelId);
				// Show the modal and hide the scrollbar
				// modal.style.display = "block";

				if (!modal) {
					console.warn("Modal not found:", panelId);
					return;
				}
				modal.classList.add("is-open");
				body.classList.add("hideScrollbar");
				html.classList.add("hideScrollbarhtml");
			});
		});
		// Add click event listeners to each close button to close the modal
		closeButtons.forEach((button) => {
			button.addEventListener("click", function (e) {
				e.stopPropagation();
				const modal = this.closest(".aboutLetterDrawer");
				if (!modal) return;
				modal.classList.remove("is-open");
				body.classList.remove("hideScrollbar");
				html.classList.remove("hideScrollbarhtml");
			});
		});
		// Close modal if clicking outside of the modal content
		window.addEventListener("click", function (event) {
			if (event.target.classList.contains("drawerOverlay")) {
				const modal = event.target.closest(".aboutLetterDrawer");

				if (!modal) return;

				modal.classList.remove("is-open");

				body.classList.remove("hideScrollbar");
				html.classList.remove("hideScrollbarhtml");
			}
		});
	});
}

// Profile drawer: opens from the right. Content is read from plain HTML, no JSON.
// Trigger: any element with data-profile-open="<id>".
// Source:  <div hidden> holding <article data-profile-item data-profile-id="<id>"> blocks. One hidden div = one Previous/Next group.
// API:     window.ProfileDrawer.open(id) / .close()
(function () {
	"use strict";

	document.addEventListener("DOMContentLoaded", function () {
		var drawer = document.querySelector("[data-profile-drawer]");
		console.log(drawer);

		if (!drawer) return;
		if (drawer.parentNode !== document.body)
			document.body.appendChild(drawer); // avoids clipping and stacking from parents

		var el = {
			scroll: drawer.querySelector(".pdScroll"),
			close: drawer.querySelector(".pdClose"),
			overlay: drawer.querySelector(".pdOverlay"),
			count: drawer.querySelector("[data-pd-count]"),
			img: drawer.querySelector("[data-pd-img]"),
			name: drawer.querySelector("[data-pd-name]"),
			role: drawer.querySelector("[data-pd-role]"),
			category: drawer.querySelector("[data-pd-category]"),
			bio: drawer.querySelector("[data-pd-bio]"),
			prev: drawer.querySelector("[data-pd-prev]"),
			next: drawer.querySelector("[data-pd-next]"),
		};

		var items = []; // profile blocks of the active group, in page order
		var index = -1;
		var opener = null;
		var isOpen = false;
		var swapTimer = null;

		function field(item, name) {
			return item.querySelector("[data-f='" + name + "']");
		}
		function text(item, name) {
			var n = field(item, name);
			return n ? n.textContent.trim() : "";
		}

		function pad(n, len) {
			n = String(n);
			while (n.length < len) n = "0" + n;
			return n;
		}

		function fill(i) {
			var item = items[i];
			var img = field(item, "image");
			var bio = field(item, "bio");
			var len = Math.max(2, String(items.length).length);
			index = i;
			el.count.textContent =
				pad(i + 1, len) + "/" + pad(items.length, len);
			el.img.src = img ? img.getAttribute("src") : "";
			el.img.alt = text(item, "name");
			el.name.textContent = text(item, "name");
			el.role.textContent = text(item, "role");
			el.role.hidden = !el.role.textContent;
			el.category.textContent = text(item, "category");
			el.category.hidden = !el.category.textContent;
			el.bio.innerHTML = bio ? bio.innerHTML : ""; // your own page markup, so links and <strong> keep working
			setNav(el.prev, items[i - 1]);
			setNav(el.next, items[i + 1]);
			el.scroll.scrollTop = 0;
		}

		function setNav(btn, target) {
			// no wrap-around: the first and last profile disable their own side
			btn.disabled = !target;
			btn.querySelector("[data-pd-nav-name]").textContent = target
				? text(target, "name")
				: "";
		}

		function go(i) {
			if (i < 0 || i >= items.length || i === index) return;
			clearTimeout(swapTimer);
			drawer.classList.add("is-swapping");
			swapTimer = setTimeout(function () {
				fill(i);
				drawer.classList.remove("is-swapping");
			}, 250);
		}

		function lockScroll(on) {
			var gap = window.innerWidth - document.documentElement.clientWidth; // keep the page from shifting when the scrollbar goes
			var html = document.documentElement;

			document.body.classList.toggle("profileDrawerOpen", on);
			document.body.classList.toggle("hideScrollbar", on);
			html.classList.toggle("hideScrollbarhtml", on);

			document.body.style.paddingRight = on && gap > 0 ? gap + "px" : "";
		}

		function open(id, trigger) {
			var all = document.querySelectorAll("[data-profile-item]");
			var item = null;
			Array.prototype.forEach.call(all, function (n) {
				if (!item && n.getAttribute("data-profile-id") === id) item = n;
			});
			if (!item) return;
			items = Array.prototype.filter.call(
				item.parentNode.children,
				function (n) {
					return n.hasAttribute("data-profile-item");
				},
			);
			opener = trigger || null;
			clearTimeout(swapTimer);
			drawer.classList.remove("is-swapping");
			fill(items.indexOf(item));
			isOpen = true;
			drawer.classList.add("is-open");
			drawer.setAttribute("aria-hidden", "false");
			lockScroll(true);
			el.close.focus();
		}

		function close() {
			if (!isOpen) return;
			isOpen = false;
			clearTimeout(swapTimer);
			drawer.classList.remove("is-open", "is-swapping");
			drawer.setAttribute("aria-hidden", "true");
			lockScroll(false);
			if (opener && document.body.contains(opener)) opener.focus();
			opener = null;
		}

		// Triggers: delegated, so cards added later (tabs, AJAX) work too.
		function triggerFrom(target) {
			return target.closest
				? target.closest("[data-profile-open]")
				: null;
		}

		document.addEventListener("click", function (e) {
			var t = triggerFrom(e.target);
			if (!t) return;
			e.preventDefault();
			open(t.getAttribute("data-profile-open"), t);
		});

		Array.prototype.forEach.call(
			document.querySelectorAll("[data-profile-open]"),
			function (t) {
				// non-button triggers (a card, an li) become keyboard accessible
				var tag = t.tagName;
				if (tag === "BUTTON" || tag === "A") return;
				if (!t.hasAttribute("tabindex"))
					t.setAttribute("tabindex", "0");
				if (!t.hasAttribute("role")) t.setAttribute("role", "button");
				t.setAttribute("aria-haspopup", "dialog");
			},
		);

		document.addEventListener("keydown", function (e) {
			if (!isOpen) {
				var t = triggerFrom(e.target);
				if (
					t &&
					(e.key === "Enter" || e.key === " ") &&
					t.tagName !== "BUTTON" &&
					t.tagName !== "A"
				) {
					e.preventDefault();
					open(t.getAttribute("data-profile-open"), t);
				}
				return;
			}
			if (e.key === "Escape") {
				close();
				return;
			}
			if (e.key === "ArrowLeft") {
				go(index - 1);
				return;
			}
			if (e.key === "ArrowRight") {
				go(index + 1);
				return;
			}
			if (e.key === "Tab") {
				// keep focus inside the open drawer
				var f = Array.prototype.filter.call(
					drawer.querySelectorAll(
						"button, a[href], [tabindex]:not([tabindex='-1'])",
					),
					function (n) {
						return !n.disabled;
					},
				);
				var first = f[0],
					last = f[f.length - 1];
				if (e.shiftKey && document.activeElement === first) {
					e.preventDefault();
					last.focus();
				} else if (!e.shiftKey && document.activeElement === last) {
					e.preventDefault();
					first.focus();
				}
			}
		});

		el.close.addEventListener("click", close);
		el.overlay.addEventListener("click", close);
		el.prev.addEventListener("click", function () {
			go(index - 1);
		});
		el.next.addEventListener("click", function () {
			go(index + 1);
		});

		window.ProfileDrawer = {
			open: function (id) {
				open(id, null);
			},
			close: close,
		};
	});
})();

// Video popup. Trigger: any element with data-video-open (link href or data-video-src gives the file).
// Optional on the trigger: data-video-poster="<image url>".
(function () {
	"use strict";

	function init() {
		var modal = document.querySelector("[data-video-modal]");
		if (!modal) return;
		if (modal.parentNode !== document.body)
			document.body.appendChild(modal); // avoids clipping and stacking from parents

		var box = modal.querySelector(".vmBox");
		var video = modal.querySelector(".vmVideo");
		var closeBtn = modal.querySelector(".vmClose");
		var opener = null;
		var isOpen = false;

		function lockScroll(on) {
			var gap = window.innerWidth - document.documentElement.clientWidth; // keeps the page from shifting when the scrollbar goes
			document.body.classList.toggle("videoModalOpen", on);
			document.body.style.paddingRight = on && gap > 0 ? gap + "px" : "";
		}

		function open(trigger) {
			var src =
				trigger.getAttribute("data-video-src") ||
				trigger.getAttribute("href");
			if (!src) return;
			opener = trigger;
			video.src = src;
			var poster = trigger.getAttribute("data-video-poster");
			if (poster) video.poster = poster;
			else video.removeAttribute("poster");
			isOpen = true;
			modal.classList.add("is-open");
			modal.setAttribute("aria-hidden", "false");
			lockScroll(true);
			closeBtn.focus();
			var played = video.play(); // allowed: it runs from the user's click
			if (played && played.catch) played.catch(function () {}); // if the browser blocks it, the controls are right there
		}

		function close() {
			if (!isOpen) return;
			isOpen = false;
			video.pause();
			modal.classList.remove("is-open");
			modal.setAttribute("aria-hidden", "true");
			lockScroll(false);
			window.setTimeout(function () {
				// after the fade, drop the file so nothing keeps loading or playing
				if (isOpen) return;
				video.removeAttribute("src");
				video.removeAttribute("poster");
				video.load();
			}, 400);
			if (opener && document.body.contains(opener)) opener.focus();
			opener = null;
		}

		document.addEventListener("click", function (e) {
			var t = e.target.closest
				? e.target.closest("[data-video-open]")
				: null;
			if (!t) return;
			e.preventDefault();
			open(t);
		});

		modal.addEventListener("click", function (e) {
			// click on the dark area around the video
			if (
				!box.contains(e.target) ||
				e.target === closeBtn ||
				closeBtn.contains(e.target)
			)
				close();
		});

		document.addEventListener("keydown", function (e) {
			if (!isOpen) return;
			if (e.key === "Escape") {
				close();
				return;
			}
			if (e.key === "Tab") {
				// keep focus on the popup: only the close button and the video controls
				var f = [closeBtn, video];
				var i = f.indexOf(document.activeElement);
				if (e.shiftKey && i <= 0) {
					e.preventDefault();
					f[f.length - 1].focus();
				} else if (!e.shiftKey && i === f.length - 1) {
					e.preventDefault();
					f[0].focus();
				}
			}
		});
	}

	if (document.readyState === "loading")
		document.addEventListener("DOMContentLoaded", init);
	else init();
})();

// Case at a glance: fills the engagement bar from the two values in the HTML, and plays the reveal once when the card scrolls into view.
// Case at a glance: fills the bars and complexity dots from the values in the HTML, and plays the reveal once when the card scrolls into view.

(function () {
	"use strict";

	var SEGMENTS = 48;
	var PERIOD = 100 / SEGMENTS;

	var DAYS = {
		day: 1,
		week: 7,
		wk: 7,
		month: 30.4375,
		mo: 30.4375,
		year: 365.25,
		yr: 365.25,
	};

	var WORDS = {
		"very low": 1,
		low: 1,
		medium: 3,
		moderate: 3,
		high: 5,
		"very high": 5,
	};

	// Convert backend value into days
	function getDays(text) {
		var match =
			/(\d+(?:[.,]\d+)?)[\s\u00a0-]*(day|week|wk|month|mo|year|yr)s?\b/i.exec(
				text || "",
			);

		if (!match) return null;

		var number = parseFloat(match[1].replace(",", "."));
		var unit = match[2].toLowerCase();

		return number * DAYS[unit];
	}

	// Calculate progress bars
	function fillBars(card) {
		var rows = Array.prototype.slice.call(
			card.querySelectorAll(".glanceBarRow"),
		);

		var days = rows.map(function (row) {
			var value = row.querySelector(".glanceBarValue");
			return value ? getDays(value.textContent.trim()) : null;
		});

		var validDays = days.filter(function (value) {
			return value !== null && isFinite(value) && value >= 0;
		});

		if (!validDays.length) return;

		var longest = Math.max.apply(null, validDays);

		if (longest <= 0) return;

		rows.forEach(function (row, index) {
			var bar = row.querySelector(".glanceBar");
			var value = row.querySelector(".glanceBarValue");

			if (!bar || days[index] === null) return;

			var fill = bar.querySelector(".glanceBarFill");

			if (!fill && row.classList.contains("is-active")) {
				fill = document.createElement("span");
				fill.className = "glanceBarFill";
				bar.appendChild(fill);
			}

			var percentage = (days[index] / longest) * 100;

			percentage = Math.max(0, Math.min(100, percentage));

			var clip = "inset(0 " + (100 - percentage).toFixed(4) + "% 0 0)";

			if (fill) {
				fill.style.clipPath = clip;
			} else {
				bar.style.clipPath = clip;
			}

			bar.setAttribute("aria-label", value.textContent.trim());
		});
	}

	// Calculate complexity dots
	function fillDots(card) {
		var dots = card.querySelector(".glanceDots");

		if (!dots) return;

		// Read score directly from backend HTML
		var score = parseFloat(dots.getAttribute("data-score"));

		if (isNaN(score)) return;

		// Keep score between 0 and 5
		score = Math.max(0, Math.min(5, score));

		Array.prototype.forEach.call(dots.children, function (dot, index) {
			var part = score - index;

			dot.className =
				part >= 0.75 ? "is-on" : part >= 0.25 ? "is-half" : "";
		});

		dots.setAttribute("aria-label", "Complexity: " + score + " out of 5");
	}

	// Refresh all cards
	function updateCards() {
		var cards = document.querySelectorAll(".caseGlance");

		Array.prototype.forEach.call(cards, function (card) {
			fillBars(card);
			fillDots(card);

			if (
				!card.classList.contains("js-reveal") &&
				!window.matchMedia("(prefers-reduced-motion: reduce)")
					.matches &&
				"IntersectionObserver" in window
			) {
				card.classList.add("js-reveal");

				var observer = new IntersectionObserver(
					function (entries) {
						if (!entries[0].isIntersecting) return;

						card.classList.add("is-in");
						observer.disconnect();
					},
					{
						threshold: 0.3,
					},
				);

				observer.observe(card);
			}
		});
	}

	function init() {
		updateCards();

		// Watch backend / AJAX HTML updates
		if ("MutationObserver" in window && document.body) {
			var mutationObserver = new MutationObserver(function () {
				updateCards();
			});

			mutationObserver.observe(document.body, {
				childList: true,
				subtree: true,
				characterData: true,
			});
		}
	}

	if (document.readyState === "loading") {
		document.addEventListener("DOMContentLoaded", init);
	} else {
		init();
	}
})();

if ($(".deployedSec").length) {
	$(".testomonialSlider").slick({
		dots: false,
		infinite: false,
		arrows: false,
		slidesToShow: 2.3,
		slidesToScroll: 1,
		autoplay: true,
		autoplaySpeed: 3000,
		speed: 1000,
		responsive: [
			{
				breakpoint: 1367,
				settings: {
					slidesToShow: 2.1,
					slidesToScroll: 1,
				},
			},
			{
				breakpoint: 1081,
				settings: {
					slidesToShow: 1.8,
					slidesToScroll: 1,
				},
			},
			{
				breakpoint: 600,
				settings: {
					slidesToShow: 1.1,
					slidesToScroll: 1,
				},
			},
		],
	});
}
// Report viewer: the left tabs switch the report panel. A tab with no matching panel yet does nothing.
(function () {
	"use strict";

	function init() {
		var viewers = document.querySelectorAll(".readinessViewer");
		Array.prototype.forEach.call(viewers, function (viewer) {
			var tabs = Array.prototype.slice.call(
				viewer.querySelectorAll("[data-rv-tab]"),
			);
			var panels = Array.prototype.slice.call(
				viewer.querySelectorAll("[data-rv-panel]"),
			);
			if (!tabs.length || !panels.length) return;

			function show(tab, focus) {
				var key = tab.getAttribute("data-rv-tab");
				var panel = viewer.querySelector(
					'[data-rv-panel="' + key + '"]',
				);
				if (!panel) {
					if (focus) tab.focus();
					return;
				} // panel not added yet: just move focus
				tabs.forEach(function (t) {
					var on = t === tab;
					t.classList.toggle("is-active", on);
					t.setAttribute("aria-selected", on ? "true" : "false");
					t.tabIndex = on ? 0 : -1;
				});
				panels.forEach(function (p) {
					var on = p === panel;
					p.classList.toggle("is-active", on);
					p.hidden = !on;
				});
				if (focus) tab.focus();
			}

			tabs.forEach(function (tab, i) {
				tab.addEventListener("click", function () {
					show(tab, false);
				});
				tab.addEventListener("keydown", function (e) {
					// arrow keys move between tabs
					var next = null;
					if (e.key === "ArrowDown" || e.key === "ArrowRight")
						next = tabs[(i + 1) % tabs.length];
					else if (e.key === "ArrowUp" || e.key === "ArrowLeft")
						next = tabs[(i - 1 + tabs.length) % tabs.length];
					else if (e.key === "Home") next = tabs[0];
					else if (e.key === "End") next = tabs[tabs.length - 1];
					if (!next) return;
					e.preventDefault();
					show(next, true);
				});
			});
		});
	}

	if (document.readyState === "loading")
		document.addEventListener("DOMContentLoaded", init);
	else init();
})();

// Apply form: shows the chosen resume file name in the upload row, and puts the placeholder text back if the file is removed.

// Apply form: shows the chosen resume file name in the upload row, and puts the placeholder text back if the file is removed.
(function () {
	"use strict";

	function init() {
		var inputs = document.querySelectorAll(".acUpload .acFile");

		Array.prototype.forEach.call(inputs, function (input) {
			var text = input.parentNode.querySelector("[data-upload-text]");

			if (!text) return;

			var placeholder = text.textContent.trim();

			input.addEventListener("change", function () {
				var file = input.files && input.files[0];

				text.textContent = file ? file.name : placeholder;

				input.parentNode.classList.toggle("has-file", !!file);

				console.log(
					"Selected file:",
					file ? file.name : "No file selected",
				);
			});
		});
	}

	if (document.readyState === "loading") {
		document.addEventListener("DOMContentLoaded", init);
	} else {
		init();
	}
})();

// Expand Box JS
(function () {
	"use strict";

	function init() {
		var sections = document.querySelectorAll(".expandBoxSec");
		Array.prototype.forEach.call(sections, function (sec) {
			var btn = sec.querySelector("[data-expand-toggle]");
			var box = sec.querySelector(".expandBox");
			if (!btn || !box) return;

			function setOpen(open) {
				sec.classList.toggle("is-open", open);
				btn.setAttribute("aria-expanded", open ? "true" : "false");
				box.setAttribute("aria-hidden", open ? "false" : "true");
			}

			btn.addEventListener("click", function (e) {
				e.preventDefault();
				setOpen(!sec.classList.contains("is-open"));
			});

			// Space key on role="button" link
			btn.addEventListener("keydown", function (e) {
				if (e.key === " " || e.key === "Spacebar") {
					e.preventDefault();
					setOpen(!sec.classList.contains("is-open"));
				}
			});

			// The page height changes when this opens or closes, so refresh ScrollTrigger once the animation ends
			box.addEventListener("transitionend", function (e) {
				if (e.propertyName === "grid-template-rows" && window.ScrollTrigger) {
					window.ScrollTrigger.refresh();
				}
			});
		});
	}

	if (document.readyState === "loading") document.addEventListener("DOMContentLoaded", init);
	else init();
})();