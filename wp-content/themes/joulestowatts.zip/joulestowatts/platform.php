<?php /* Template Name: Platform */ get_header(); ?>

<section class="bannerInnerSection">
    <div class="wrapper">
        <?php if( have_rows('banner_section') ): ?>
            <?php while( have_rows('banner_section') ): the_row(); ?>
                <div class="bannerContent">
                    <div class="bannerHeading">
                        <h1 class="manrope"><?php echo wp_kses_post( get_sub_field('heading') ); ?></h1>
                        <p><?php echo wp_kses_post( get_sub_field('description') ); ?></p>
                        <ul class="bannerctaList">
                            <?php if( have_rows('cta_lists') ): ?>
                                <?php while( have_rows('cta_lists') ): the_row(); ?>
                                    <li>
                                        <a href="<?php echo esc_url( get_sub_field('cta_link') ); ?>"><?php echo esc_html( get_sub_field('cta_text') ); ?></a>
                                    </li>
                                <?php endwhile; ?>
                            <?php endif; ?>
                        </ul>
                    </div>
                    <?php $bannerimg = get_sub_field('banner_image'); if( !empty( $bannerimg ) ): ?>
                        <img src="<?php echo esc_url($bannerimg['url']); ?>" loading="lazy" alt="<?php echo esc_attr($bannerimg['alt']); ?>" />
                    <?php endif; ?>
                </div>
            <?php endwhile; ?>
        <?php endif; ?>
    </div>
    <div class="bannerBG">
        <svg xmlns="http://www.w3.org/2000/svg" width="2168" height="658" viewBox="0 0 2168 658" fill="none">
            <g filter="url(#filter0_f_952_6788)">
                <path d="M1891.15 658C1891.15 517.314 1806.12 382.39 1654.74 282.91C1503.37 183.43 1298.07 127.542 1084 127.542C869.929 127.542 664.626 183.43 513.255 282.91C361.885 382.39 276.845 517.314 276.845 658L1891.15 658Z" fill="url(#paint0_linear_952_6788)" fill-opacity="0.984314"/>
            </g>
            <defs>
                <filter id="filter0_f_952_6788" x="-123.155" y="-272.458" width="2414.31" height="1330.46" filterUnits="userSpaceOnUse" color-interpolation-filters="sRGB">
                    <feFlood flood-opacity="0" result="BackgroundImageFix"/>
                    <feBlend mode="normal" in="SourceGraphic" in2="BackgroundImageFix" result="shape"/>
                    <feGaussianBlur stdDeviation="200" result="effect1_foregroundBlur_952_6788"/>
                </filter>
                <linearGradient id="paint0_linear_952_6788" x1="1084" y1="658" x2="1109.13" y2="-74.7586" gradientUnits="userSpaceOnUse">
                    <stop stop-color="#01D3C7"/>
                    <stop offset="0.151345" stop-color="#08A8A2" stop-opacity="0.57"/>
                    <stop offset="0.237738" stop-color="#0B908E" stop-opacity="0.49"/>
                    <stop offset="0.320429" stop-color="#0F797A" stop-opacity="0.34"/>
                    <stop offset="0.43204" stop-color="#14595F" stop-opacity="0.28"/>
                    <stop offset="0.740931" stop-color="#210214" stop-opacity="0"/>
                    <stop offset="1" stop-color="#210214"/>
                </linearGradient>
            </defs>
        </svg>
    </div>
</section>

<section class="diagnosisSection" id="diagnosis">
    <div class="diagnosisBG">
        <svg xmlns="http://www.w3.org/2000/svg" width="2168" height="658" viewBox="0 0 2168 658" fill="none">
            <g filter="url(#filter0_f_952_6788)">
                <path d="M1891.15 658C1891.15 517.314 1806.12 382.39 1654.74 282.91C1503.37 183.43 1298.07 127.542 1084 127.542C869.929 127.542 664.626 183.43 513.255 282.91C361.885 382.39 276.845 517.314 276.845 658L1891.15 658Z" fill="url(#paint0_linear_952_6788)" fill-opacity="0.984314"/>
            </g>
            <defs>
                <filter id="filter0_f_952_6788" x="-123.155" y="-272.458" width="2414.31" height="1330.46" filterUnits="userSpaceOnUse" color-interpolation-filters="sRGB">
                    <feFlood flood-opacity="0" result="BackgroundImageFix"/>
                    <feBlend mode="normal" in="SourceGraphic" in2="BackgroundImageFix" result="shape"/>
                    <feGaussianBlur stdDeviation="200" result="effect1_foregroundBlur_952_6788"/>
                </filter>
                <linearGradient id="paint0_linear_952_6788" x1="1084" y1="658" x2="1109.13" y2="-74.7586" gradientUnits="userSpaceOnUse">
                    <stop stop-color="#01D3C7"/>
                    <stop offset="0.151345" stop-color="#08A8A2" stop-opacity="0.57"/>
                    <stop offset="0.237738" stop-color="#0B908E" stop-opacity="0.49"/>
                    <stop offset="0.320429" stop-color="#0F797A" stop-opacity="0.34"/>
                    <stop offset="0.43204" stop-color="#14595F" stop-opacity="0.28"/>
                    <stop offset="0.740931" stop-color="#210214" stop-opacity="0"/>
                    <stop offset="1" stop-color="#210214"/>
                </linearGradient>
            </defs>
        </svg>
    </div>
    <div class="wrapper">
        <?php if( have_rows('diagnosis_section') ): ?>
            <?php while( have_rows('diagnosis_section') ): the_row(); ?>
                <div class="secHeading">
                    <h4 class="manrope"><?php echo esc_html( get_sub_field('sub_heading') ); ?></h4>
                    <h2 class="manrope"><?php echo wp_kses_post( get_sub_field('heading') ); ?></h2>
                    <p><?php echo wp_kses_post( get_sub_field('description') ); ?></p>
                </div>
                <div class="diagnosisContent">
                    <?php if( have_rows('left_content') ): ?>
                        <?php while( have_rows('left_content') ): the_row(); ?>
                            <div class="leftBox">
                                <h3><?php echo wp_kses_post( get_sub_field('heading') ); ?></h3>
                                <p><?php echo wp_kses_post( get_sub_field('description') ); ?></p>
                            </div>
                        <?php endwhile; ?>
                    <?php endif; ?>
                    <?php if( have_rows('middle_box') ): ?>
                        <?php while( have_rows('middle_box') ): the_row(); ?>
                            <div class="middleBox">
                                <?php $diagnosisimg = get_sub_field('image_box'); if( !empty( $diagnosisimg ) ): ?>
                                    <img src="<?php echo esc_url($diagnosisimg['url']); ?>" loading="lazy" alt="<?php echo esc_attr($diagnosisimg['alt']); ?>" />
                                <?php endif; ?>
                                <?php if( get_sub_field('image_heading') ): ?>
                                    <p><?php echo esc_html( get_sub_field('image_heading') ); ?></p>
                                <?php endif; ?>
                            </div>
                        <?php endwhile; ?>
                    <?php endif; ?>
                    <?php if( have_rows('right_content') ): ?>
                        <?php while( have_rows('right_content') ): the_row(); ?>
                            <div class="rightBox">
                                <h3><?php echo wp_kses_post( get_sub_field('heading') ); ?></h3>
                                <p><?php echo wp_kses_post( get_sub_field('description') ); ?></p>
                            </div>
                        <?php endwhile; ?>
                    <?php endif; ?>
                </div>
            <?php endwhile; ?>
        <?php endif; ?>
    </div>
</section>

<section class="platformRouteSec">
    <div class="wrapper">
        <?php if( have_rows('video_section') ): ?>
            <div class="routeCards">
                <?php while( have_rows('video_section') ): the_row(); ?>
                    <div class="routeCard">
                        <div class="routeContent">
                            <h3 class="manrope"><?php echo esc_html( get_sub_field('sub_heading') ); ?></h3>
                            <h2 class="manrope"><?php echo wp_kses_post( get_sub_field('heading') ); ?></h2>
                            <p><?php echo wp_kses_post( get_sub_field('description') ); ?></p>
                            <?php if( get_sub_field('cta_text') ): ?>
                                <a href="<?php echo esc_url( get_sub_field('cta_link') ? get_sub_field('cta_link') : '#' ); ?>" class="secondaryCTA">
                                    <span><?php echo esc_html( get_sub_field('cta_text') ); ?></span>
                                    <div class="arrowBox">
                                        <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none">
                                            <path d="M18.7504 15.7496V5.99958C18.7504 5.80067 18.6714 5.6099 18.5307 5.46925C18.3901 5.3286 18.1993 5.24958 18.0004 5.24958H8.25042C8.0515 5.24958 7.86074 5.3286 7.72009 5.46925C7.57943 5.6099 7.50042 5.80067 7.50042 5.99958C7.50042 6.19849 7.57943 6.38926 7.72009 6.52991C7.86074 6.67057 8.0515 6.74958 8.25042 6.74958H16.1901L5.46979 17.469C5.32906 17.6097 5.25 17.8006 5.25 17.9996C5.25 18.1986 5.32906 18.3895 5.46979 18.5302C5.61052 18.6709 5.80139 18.75 6.00042 18.75C6.19944 18.75 6.39031 18.6709 6.53104 18.5302L17.2504 7.8099V15.7496C17.2504 15.9485 17.3294 16.1393 17.4701 16.2799C17.6107 16.4206 17.8015 16.4996 18.0004 16.4996C18.1993 16.4996 18.3901 16.4206 18.5307 16.2799C18.6714 16.1393 18.7504 15.9485 18.7504 15.7496Z" fill="#19060F"/>
                                        </svg>
                                    </div>
                                </a>
                            <?php endif; ?>
                        </div>
                    </div>
                <?php endwhile; ?>
            </div>
        <?php endif; ?>
        <?php if( get_field('route_track_label') ): ?>
            <div class="routeTrack" data-reveal>
                <div class="trackLine"><span class="trackDot"></span></div>
                <p class="manrope"><?php echo esc_html( get_field('route_track_label') ); ?></p>
            </div>
        <?php endif; ?>
    </div>
</section>

<section class="pointitSection homeImpactSec platformPointSec" id="pointit">
    <div class="homeImpactGlow" aria-hidden="true">
        <img src="<?php echo get_template_directory_uri(); ?>/images/home-glow.webp" alt="" />
        <img src="<?php echo get_template_directory_uri(); ?>/images/home-glow.webp" alt="" />
    </div>
    <?php if( have_rows('diagnosis_pointit_section') ): ?>
        <?php while( have_rows('diagnosis_pointit_section') ): the_row(); ?>
            <div class="wrapper">
                <div class="pointitContent">
                    <div class="secHeading">
                        <h4 class="manrope"><?php echo esc_html( get_sub_field('sub_heading') ); ?></h4>
                        <h2 class="manrope"><?php echo wp_kses_post( get_sub_field('heading') ); ?></h2>
                        <p><?php echo wp_kses_post( get_sub_field('description') ); ?></p>
                    </div>
                    <div class="pointitAnim pointLine" data-reveal>
                        <img class="pointLineArt" src="<?php echo esc_url( get_template_directory_uri() ); ?>/images/platform-talent-technology-line.svg" alt="" loading="lazy" />
                        <?php if( have_rows('pins') ): ?>
                            <?php $pin = 1; while( have_rows('pins') ): the_row(); ?>
                                <div class="pointPin pointPin<?php echo (int) $pin; ?>">
                                    <h3><?php echo esc_html( get_sub_field('title') ); ?></h3>
                                    <p><?php echo esc_html( get_sub_field('text') ); ?></p>
                                </div>
                            <?php $pin++; endwhile; ?>
                        <?php endif; ?>
                        <span class="pinMark pinMark1" aria-hidden="true"></span>
                        <span class="pinMark pinMark2" aria-hidden="true"></span>
                    </div>
                </div>
                <div class="pointitLinks">
                    <?php if( have_rows('cta_group') ): ?>
                        <?php while( have_rows('cta_group') ): the_row(); ?>
                            <a href="<?php echo esc_url( get_sub_field('cta_link') ? get_sub_field('cta_link') : '#' ); ?>"><?php echo esc_html( get_sub_field('cta_text') ); ?>
                                <span>
                                    <svg width="15" height="12" viewBox="0 0 15 12" fill="none" xmlns="http://www.w3.org/2000/svg">
                                            <path d="M5.43594e-05 5.88268C5.43594e-05 6.03869 0.0620279 6.18831 0.172344 6.29863C0.28266 6.40894 0.43228 6.47091 0.588289 6.47091H12.1096L7.81917 10.7606C7.76452 10.8153 7.72117 10.8802 7.69159 10.9516C7.66201 11.023 7.64679 11.0995 7.64679 11.1768C7.64679 11.2541 7.66201 11.3306 7.69159 11.402C7.72117 11.4734 7.76452 11.5383 7.81917 11.593C7.87382 11.6476 7.93871 11.691 8.01011 11.7206C8.08152 11.7501 8.15806 11.7654 8.23535 11.7654C8.31264 11.7654 8.38917 11.7501 8.46058 11.7206C8.53199 11.691 8.59687 11.6476 8.65153 11.593L13.9456 6.29886C14.0003 6.24423 14.0437 6.17935 14.0733 6.10794C14.1029 6.03653 14.1182 5.95998 14.1182 5.88268C14.1182 5.80538 14.1029 5.72883 14.0733 5.65742C14.0437 5.58601 14.0003 5.52113 13.9456 5.4665L8.65153 0.172386C8.54115 0.062009 8.39144 -1.16301e-09 8.23535 0C8.07925 1.16301e-09 7.92955 0.062009 7.81917 0.172386C7.70879 0.282763 7.64679 0.432466 7.64679 0.588562C7.64679 0.744659 7.70879 0.894362 7.81917 1.00474L12.1096 5.29444H0.588289C0.43228 5.29444 0.28266 5.35642 0.172344 5.46673C0.0620279 5.57705 5.43594e-05 5.72667 5.43594e-05 5.88268Z" fill="white"/>
                                        </svg>
                                </span>
                            </a>
                        <?php endwhile; ?>
                    <?php endif; ?>
                </div>
            </div>
        <?php endwhile; ?>
    <?php endif; ?>
</section>

<section class="solutionSection scrollAnimation" id="offerings">
    <div class="secWrapper">
        <?php if( have_rows('solution_section') ): ?>
            <?php while( have_rows('solution_section') ): the_row(); ?>
                <div class="secHeading">
                    <h2 class="manrope"><?php echo wp_kses_post( get_sub_field('heading') ); ?></h2>
                    <?php if( get_sub_field('description') ): ?>
                        <p><?php echo wp_kses_post( get_sub_field('description') ); ?></p>
                    <?php endif; ?>
                </div>
                <div class="cardContainer" data-accordion>
                    <?php if( have_rows('solution_content') ): ?>
                        <?php $solutionsec = get_field('solution_section'); $solutioncount = ! empty( $solutionsec['solution_content'] ) ? count( $solutionsec['solution_content'] ) : 0; $counter=1; while( have_rows('solution_content') ): the_row(); ?>
                            <div class="solutionCard" data-accordion-item role="button" tabindex="0" aria-expanded="false">
                                
                                <div class="imgBox">
                                    <?php $solutionimg = get_sub_field('box_image'); if( !empty( $solutionimg ) ): ?>
                                        <img src="<?php echo esc_url($solutionimg['url']); ?>" loading="lazy" alt="<?php echo esc_attr($solutionimg['alt']); ?>" />
                                    <?php endif; ?>
                                </div>
                                <div class="bottomContent">
                                    <?php $boxLink = get_sub_field('box_link'); ?>
                                    <a <?php echo $boxLink ? 'href="' . esc_url( $boxLink ) . '"' : 'tabindex="0"'; ?>>
                                        <span class="manrope num"><?php echo sprintf('%02d', $counter); ?></span>
                                        <h3 class="manrope"><?php echo wp_kses_post( get_sub_field('box_heading') ); ?></h3>
                                        <div class="description">
                                            <div class="descriptionInner">
                                                <p><?php echo wp_kses_post( get_sub_field('box_description') ); ?></p>
                                            </div>
                                        </div>
                                    </a>
                                </div>
                            </div>
                        <?php $counter++; endwhile; ?>
                    <?php endif; ?>
                </div>
            <?php endwhile; ?>
        <?php endif; ?>
    </div>
</section>

<section class="talkToPartnerSec">
    <div class="secWrapper">
        <?php if( have_rows('talk_to_partner') ): ?>
            <?php while( have_rows('talk_to_partner') ): the_row(); ?>
                <div class="secHeading">
                    <h2 class="manrope"><?php echo wp_kses_post( get_sub_field('heading') ); ?></h2>
                    <p><?php echo wp_kses_post( get_sub_field('description') ); ?></p>
                    <a href="<?php echo esc_url( get_sub_field('cta_link') ? get_sub_field('cta_link') : '#' ); ?>" class="primaryCTA"><span><?php echo esc_html( get_sub_field('cta_text') ); ?></span>
                        <div class="arrowBox">
                            <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none">
                                <path d="M18.7504 15.7496V5.99958C18.7504 5.80067 18.6714 5.6099 18.5307 5.46925C18.3901 5.3286 18.1993 5.24958 18.0004 5.24958H8.25042C8.0515 5.24958 7.86074 5.3286 7.72009 5.46925C7.57943 5.6099 7.50042 5.80067 7.50042 5.99958C7.50042 6.19849 7.57943 6.38926 7.72009 6.52991C7.86074 6.67057 8.0515 6.74958 8.25042 6.74958H16.1901L5.46979 17.469C5.32906 17.6097 5.25 17.8006 5.25 17.9996C5.25 18.1986 5.32906 18.3895 5.46979 18.5302C5.61052 18.6709 5.80139 18.75 6.00042 18.75C6.19944 18.75 6.39031 18.6709 6.53104 18.5302L17.2504 7.8099V15.7496C17.2504 15.9485 17.3294 16.1393 17.4701 16.2799C17.6107 16.4206 17.8015 16.4996 18.0004 16.4996C18.1993 16.4996 18.3901 16.4206 18.5307 16.2799C18.6714 16.1393 18.7504 15.9485 18.7504 15.7496Z" fill="#19060F"/>
                            </svg>
                        </div>
                    </a>
                </div>
            <?php endwhile; ?>
        <?php endif; ?>
    </div>
</section>

<section class="ourAiSection" id="ips">
    <div class="wrapper">
        <?php if( have_rows('our_ai_section') ): ?>
            <?php while( have_rows('our_ai_section') ): the_row(); ?>
                <div class="mainContainer">
                    <div class="leftTextPart">
                        <div class="secHeading">
                            <h3 class="manrope"><?php echo esc_html( get_sub_field('sub_heading') ); ?></h3>
                            <h2 class="manrope"><?php echo wp_kses_post( get_sub_field('heading') ); ?></h2>
                            <div class="descriptionGrop">
                                <p><?php echo get_sub_field('description'); ?></p>
                            </div>
                        </div>
                        <div class="cardHeadingGroup">
                            <?php if( have_rows('our_ai_content') ): ?>
                                <?php while( have_rows('our_ai_content') ): the_row(); ?>
                                    <div class="cardHeading">
                                        <?php if( get_sub_field('sub_heading') ): ?><h5 class="manrope"><?php echo esc_html( get_sub_field('sub_heading') ); ?></h5><?php endif; ?>
                                        <h4 class="manrope"><?php echo get_sub_field('heading'); ?></h4>
                                        <p><?php echo get_sub_field('description'); ?></p>
                                        <span class="tagLine"><?php echo get_sub_field('sub_pointer'); ?></span>
                                        <a href="<?php echo get_sub_field('cta_link'); ?>" class="exploreBtn"><?php echo get_sub_field('cta_text'); ?>
                                            <span>
                                                <svg xmlns="http://www.w3.org/2000/svg" width="15" height="12" viewBox="0 0 15 12" fill="none">
                                                    <path d="M-6.67572e-06 5.88268C-6.67572e-06 6.03869 0.0619669 6.18831 0.172283 6.29863C0.282598 6.40894 0.432219 6.47091 0.588228 6.47091H12.1096L7.81911 10.7606C7.76446 10.8153 7.7211 10.8802 7.69153 10.9516C7.66195 11.023 7.64672 11.0995 7.64672 11.1768C7.64672 11.2541 7.66195 11.3306 7.69153 11.402C7.7211 11.4734 7.76446 11.5383 7.81911 11.593C7.87376 11.6476 7.93865 11.691 8.01005 11.7206C8.08146 11.7501 8.158 11.7654 8.23529 11.7654C8.31258 11.7654 8.38911 11.7501 8.46052 11.7206C8.53193 11.691 8.59681 11.6476 8.65146 11.593L13.9456 6.29886C14.0003 6.24423 14.0437 6.17935 14.0733 6.10794C14.1029 6.03653 14.1181 5.95998 14.1181 5.88268C14.1181 5.80538 14.1029 5.72883 14.0733 5.65742C14.0437 5.58601 14.0003 5.52113 13.9456 5.4665L8.65146 0.172386C8.54109 0.062009 8.39138 -1.16301e-09 8.23529 0C8.07919 1.16301e-09 7.92949 0.062009 7.81911 0.172386C7.70873 0.282763 7.64672 0.432466 7.64672 0.588562C7.64672 0.744659 7.70873 0.894362 7.81911 1.00474L12.1096 5.29444H0.588228C0.432219 5.29444 0.282598 5.35642 0.172283 5.46673C0.0619669 5.57705 -6.67572e-06 5.72667 -6.67572e-06 5.88268Z" fill="white"/>
                                                </svg>
                                            </span>
                                        </a>
                                    </div>
                                <?php endwhile; ?>
                            <?php endif; ?>
                        </div>
                    </div>
                    <div class="righttextPart">
                        <div class="track">
                            <?php if( have_rows('our_ai_content') ): ?>
                                <?php while( have_rows('our_ai_content') ): the_row(); ?>
                                    <div class="aiImgBox">
                                        <?php $ouraiimg = get_sub_field('image_box'); if( !empty( $ouraiimg ) ): ?>
                                            <img src="<?php echo esc_url($ouraiimg['url']); ?>" alt="<?php echo esc_attr($ouraiimg['alt']); ?>" />
                                        <?php endif; ?>
                                    </div>
                                <?php endwhile; ?>
                            <?php endif; ?>
                        </div>
                        <div class="arrowBox">
                            <span class="aiSecPrevArrow ">
                                <svg xmlns="http://www.w3.org/2000/svg" width="26" height="22" viewBox="0 0 26 22" fill="none">
                                    <path d="M9.90509 20.9813L0.305793 11.382C0.109955 11.1861 -6.67789e-05 10.9205 -6.81276e-05 10.6436C-6.67789e-05 10.3666 0.109955 10.101 0.305793 9.90515L9.90509 0.305849C10.1009 0.110011 10.3665 -1.03086e-05 10.6435 -1.0983e-05C10.9205 -1.014e-05 11.1861 0.11001 11.3819 0.305848C11.5777 0.501686 11.6878 0.7673 11.6878 1.04426C11.6878 1.32121 11.5777 1.58683 11.3819 1.78266L3.56494 9.59963L24.6732 9.59871C24.9504 9.59871 25.2161 9.70879 25.4121 9.90474C25.608 10.1007 25.7181 10.3664 25.7181 10.6436C25.7181 10.9207 25.608 11.1864 25.4121 11.3824C25.2161 11.5783 24.9504 11.6884 24.6732 11.6884L3.56494 11.6875L11.3819 19.5044C11.5777 19.7003 11.6878 19.9659 11.6878 20.2429C11.6878 20.5198 11.5777 20.7854 11.3819 20.9813C11.1861 21.1771 10.9205 21.2871 10.6435 21.2871C10.3665 21.2871 10.1009 21.1771 9.90509 20.9813Z" fill="#19060F"/>
                                </svg>
                            </span>
                            <span class="aiSecNextArrow">
                                <svg xmlns="http://www.w3.org/2000/svg" width="26" height="22" viewBox="0 0 26 22" fill="none">
                                    <path d="M15.8129 20.9813L25.4122 11.382C25.6081 11.1861 25.7181 10.9205 25.7181 10.6436C25.7181 10.3666 25.6081 10.101 25.4122 9.90515L15.8129 0.305849C15.6171 0.110011 15.3515 -1.03086e-05 15.0745 -1.0983e-05C14.7976 -1.014e-05 14.5319 0.11001 14.3361 0.305848C14.1403 0.501686 14.0303 0.7673 14.0303 1.04426C14.0303 1.32121 14.1403 1.58683 14.3361 1.78266L22.1531 9.59963L1.04478 9.59871C0.767665 9.59871 0.501903 9.70879 0.305957 9.90474C0.11001 10.1007 -7.1796e-05 10.3664 -7.17854e-05 10.6436C-7.1796e-05 10.9207 0.11001 11.1864 0.305957 11.3824C0.501903 11.5783 0.767665 11.6884 1.04478 11.6884L22.1531 11.6875L14.3361 19.5044C14.1403 19.7003 14.0303 19.9659 14.0303 20.2429C14.0303 20.5198 14.1403 20.7854 14.3361 20.9813C14.5319 21.1771 14.7976 21.2871 15.0745 21.2871C15.3515 21.2871 15.6171 21.1771 15.8129 20.9813Z" fill="#19060F"/>
                                </svg>
                            </span>
                        </div>
                    </div>
                </div>
                <div class="mblMainContainer">
                    <div class="secHeadingMbl">
                        <h3 class="manrope"><?php echo esc_html( get_sub_field('sub_heading') ); ?></h3>
                        <h2 class="manrope"><?php echo wp_kses_post( get_sub_field('heading') ); ?></h2>
                        <div class="descriptionGrop">
                            <p><?php echo get_sub_field('description'); ?></p>
                        </div>
                    </div>
                    <div class="righttextPart ">
                        <div class="aiImgSlider">
                            <?php if( have_rows('our_ai_content') ): ?>
                                <?php while( have_rows('our_ai_content') ): the_row(); ?>
                                    <div class="aiImgBox">
                                        <?php $ouraiimg = get_sub_field('image_box'); if( !empty( $ouraiimg ) ): ?>
                                            <img src="<?php echo esc_url($ouraiimg['url']); ?>" loading="lazy" alt="<?php echo esc_attr($ouraiimg['alt']); ?>" />
                                        <?php endif; ?>
                                    </div>
                                <?php endwhile; ?>
                            <?php endif; ?>
                        </div>
                        <div class="arrowBox">
                            <span class="aiSecPrevArrow ">
                                <svg xmlns="http://www.w3.org/2000/svg" width="26" height="22" viewBox="0 0 26 22" fill="none">
                                    <path d="M9.90509 20.9813L0.305793 11.382C0.109955 11.1861 -6.67789e-05 10.9205 -6.81276e-05 10.6436C-6.67789e-05 10.3666 0.109955 10.101 0.305793 9.90515L9.90509 0.305849C10.1009 0.110011 10.3665 -1.03086e-05 10.6435 -1.0983e-05C10.9205 -1.014e-05 11.1861 0.11001 11.3819 0.305848C11.5777 0.501686 11.6878 0.7673 11.6878 1.04426C11.6878 1.32121 11.5777 1.58683 11.3819 1.78266L3.56494 9.59963L24.6732 9.59871C24.9504 9.59871 25.2161 9.70879 25.4121 9.90474C25.608 10.1007 25.7181 10.3664 25.7181 10.6436C25.7181 10.9207 25.608 11.1864 25.4121 11.3824C25.2161 11.5783 24.9504 11.6884 24.6732 11.6884L3.56494 11.6875L11.3819 19.5044C11.5777 19.7003 11.6878 19.9659 11.6878 20.2429C11.6878 20.5198 11.5777 20.7854 11.3819 20.9813C11.1861 21.1771 10.9205 21.2871 10.6435 21.2871C10.3665 21.2871 10.1009 21.1771 9.90509 20.9813Z" fill="#19060F"/>
                                </svg>
                            </span>
                            <span class="aiSecNextArrow">
                                <svg xmlns="http://www.w3.org/2000/svg" width="26" height="22" viewBox="0 0 26 22" fill="none">
                                    <path d="M15.8129 20.9813L25.4122 11.382C25.6081 11.1861 25.7181 10.9205 25.7181 10.6436C25.7181 10.3666 25.6081 10.101 25.4122 9.90515L15.8129 0.305849C15.6171 0.110011 15.3515 -1.03086e-05 15.0745 -1.0983e-05C14.7976 -1.014e-05 14.5319 0.11001 14.3361 0.305848C14.1403 0.501686 14.0303 0.7673 14.0303 1.04426C14.0303 1.32121 14.1403 1.58683 14.3361 1.78266L22.1531 9.59963L1.04478 9.59871C0.767665 9.59871 0.501903 9.70879 0.305957 9.90474C0.11001 10.1007 -7.1796e-05 10.3664 -7.17854e-05 10.6436C-7.1796e-05 10.9207 0.11001 11.1864 0.305957 11.3824C0.501903 11.5783 0.767665 11.6884 1.04478 11.6884L22.1531 11.6875L14.3361 19.5044C14.1403 19.7003 14.0303 19.9659 14.0303 20.2429C14.0303 20.5198 14.1403 20.7854 14.3361 20.9813C14.5319 21.1771 14.7976 21.2871 15.0745 21.2871C15.3515 21.2871 15.6171 21.1771 15.8129 20.9813Z" fill="#19060F"/>
                                </svg>
                            </span>
                        </div>
                    </div>
                    <div class="leftTextPart">
                        <div class="aiTextSlider">
                            <?php if( have_rows('our_ai_content') ): ?>
                                <?php while( have_rows('our_ai_content') ): the_row(); ?>
                                    <div class="cardHeading">
                                        <?php if( get_sub_field('sub_heading') ): ?><h5 class="manrope"><?php echo esc_html( get_sub_field('sub_heading') ); ?></h5><?php endif; ?>
                                        <h4 class="manrope"><?php echo get_sub_field('heading'); ?></h4>
                                        <p><?php echo get_sub_field('description'); ?></p>
                                        <span class="tagLine"><?php echo get_sub_field('sub_pointer'); ?></span>
                                        <a href="<?php echo get_sub_field('cta_link'); ?>" class="exploreBtn"><?php echo get_sub_field('cta_text'); ?>
                                            <span>
                                                <svg xmlns="http://www.w3.org/2000/svg" width="15" height="12" viewBox="0 0 15 12" fill="none">
                                                    <path d="M-6.67572e-06 5.88268C-6.67572e-06 6.03869 0.0619669 6.18831 0.172283 6.29863C0.282598 6.40894 0.432219 6.47091 0.588228 6.47091H12.1096L7.81911 10.7606C7.76446 10.8153 7.7211 10.8802 7.69153 10.9516C7.66195 11.023 7.64672 11.0995 7.64672 11.1768C7.64672 11.2541 7.66195 11.3306 7.69153 11.402C7.7211 11.4734 7.76446 11.5383 7.81911 11.593C7.87376 11.6476 7.93865 11.691 8.01005 11.7206C8.08146 11.7501 8.158 11.7654 8.23529 11.7654C8.31258 11.7654 8.38911 11.7501 8.46052 11.7206C8.53193 11.691 8.59681 11.6476 8.65146 11.593L13.9456 6.29886C14.0003 6.24423 14.0437 6.17935 14.0733 6.10794C14.1029 6.03653 14.1181 5.95998 14.1181 5.88268C14.1181 5.80538 14.1029 5.72883 14.0733 5.65742C14.0437 5.58601 14.0003 5.52113 13.9456 5.4665L8.65146 0.172386C8.54109 0.062009 8.39138 -1.16301e-09 8.23529 0C8.07919 1.16301e-09 7.92949 0.062009 7.81911 0.172386C7.70873 0.282763 7.64672 0.432466 7.64672 0.588562C7.64672 0.744659 7.70873 0.894362 7.81911 1.00474L12.1096 5.29444H0.588228C0.432219 5.29444 0.282598 5.35642 0.172283 5.46673C0.0619669 5.57705 -6.67572e-06 5.72667 -6.67572e-06 5.88268Z" fill="white"/>
                                                </svg>
                                            </span>
                                        </a>
                                    </div>
                                <?php endwhile; ?>
                            <?php endif; ?>
                        </div>
                    </div>
                </div>
            <?php endwhile; ?>
        <?php endif; ?>
    </div>
</section>

<section class="resultSection homeImpactSec">
    <div class="homeImpactGlow" aria-hidden="true">
        <img src="<?php echo get_template_directory_uri(); ?>/images/home-glow.webp" alt="" />
        <img src="<?php echo get_template_directory_uri(); ?>/images/home-glow.webp" alt="" />
    </div>
    <div class="secWrapper">
        <?php if( have_rows('results_section') ): ?>
            <?php while( have_rows('results_section') ): the_row(); ?>
                <div class="secHeading ">
                    <div class="headingGroup">
                        <h2 class="manrope"><?php echo wp_kses_post( get_sub_field('heading') ); ?></h2>
                        <?php foreach( preg_split( '#(?:<br\s*/?>\s*){2,}#i', (string) get_sub_field('description') ) as $resultpara ): ?>
                            <p><?php echo wp_kses_post( trim( $resultpara ) ); ?></p>
                        <?php endforeach; ?>
                    </div>
                    <a href="<?php echo esc_url( get_sub_field('cta_link') ? get_sub_field('cta_link') : '#' ); ?>" class="primaryCTA"><span><?php echo esc_html( get_sub_field('cta_text') ); ?></span>
                        <div class="arrowBox">
                            <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none">
                                <path d="M18.7504 15.7496V5.99958C18.7504 5.80067 18.6714 5.6099 18.5307 5.46925C18.3901 5.3286 18.1993 5.24958 18.0004 5.24958H8.25042C8.0515 5.24958 7.86074 5.3286 7.72009 5.46925C7.57943 5.6099 7.50042 5.80067 7.50042 5.99958C7.50042 6.19849 7.57943 6.38926 7.72009 6.52991C7.86074 6.67057 8.0515 6.74958 8.25042 6.74958H16.1901L5.46979 17.469C5.32906 17.6097 5.25 17.8006 5.25 17.9996C5.25 18.1986 5.32906 18.3895 5.46979 18.5302C5.61052 18.6709 5.80139 18.75 6.00042 18.75C6.19944 18.75 6.39031 18.6709 6.53104 18.5302L17.2504 7.8099V15.7496C17.2504 15.9485 17.3294 16.1393 17.4701 16.2799C17.6107 16.4206 17.8015 16.4996 18.0004 16.4996C18.1993 16.4996 18.3901 16.4206 18.5307 16.2799C18.6714 16.1393 18.7504 15.9485 18.7504 15.7496Z" fill="#19060F"/>
                            </svg>
                        </div>
                    </a>
                </div>
                <div class="resultsCardLayout">
                    <div class="commanCard resultCardSlider" data-toggle-group>
                        <?php if( have_rows('results_content') ): ?>
                            <?php while( have_rows('results_content') ): the_row(); ?>
                                <a <?php if( get_sub_field('box_link') ): ?>href="<?php echo esc_url( get_sub_field('box_link') ); ?>"<?php endif; ?> data-toggle-item>
                                    <div class="box" data-toggle role="button" tabindex="0" aria-expanded="false">
                                        <span class="tag manrope"><?php echo esc_html( get_sub_field('box_tag') ); ?></span>
                                        <div class="bottomContent">
                                            <h3 class="manrope"><?php echo esc_html( get_sub_field('box_heading') ); ?></h3>
                                            <?php if( get_sub_field('box_description') ): ?>
                                                <div class="moreContent"><p><?php echo esc_html( get_sub_field('box_description') ); ?></p></div>
                                            <?php endif; ?>
                                        </div>
                                    </div>
                                </a>
                            <?php endwhile; ?>
                        <?php endif; ?>
                    </div>
                    <div class="arrowBox">
                        <span class="platformResultPrevArrow ">
                            <svg xmlns="http://www.w3.org/2000/svg" width="26" height="22" viewBox="0 0 26 22" fill="none">
                                <path d="M9.90509 20.9813L0.305793 11.382C0.109955 11.1861 -6.67789e-05 10.9205 -6.81276e-05 10.6436C-6.67789e-05 10.3666 0.109955 10.101 0.305793 9.90515L9.90509 0.305849C10.1009 0.110011 10.3665 -1.03086e-05 10.6435 -1.0983e-05C10.9205 -1.014e-05 11.1861 0.11001 11.3819 0.305848C11.5777 0.501686 11.6878 0.7673 11.6878 1.04426C11.6878 1.32121 11.5777 1.58683 11.3819 1.78266L3.56494 9.59963L24.6732 9.59871C24.9504 9.59871 25.2161 9.70879 25.4121 9.90474C25.608 10.1007 25.7181 10.3664 25.7181 10.6436C25.7181 10.9207 25.608 11.1864 25.4121 11.3824C25.2161 11.5783 24.9504 11.6884 24.6732 11.6884L3.56494 11.6875L11.3819 19.5044C11.5777 19.7003 11.6878 19.9659 11.6878 20.2429C11.6878 20.5198 11.5777 20.7854 11.3819 20.9813C11.1861 21.1771 10.9205 21.2871 10.6435 21.2871C10.3665 21.2871 10.1009 21.1771 9.90509 20.9813Z" fill="#19060F"/>
                            </svg>
                        </span>
                        <span class="platformResultNextArrow">
                            <svg xmlns="http://www.w3.org/2000/svg" width="26" height="22" viewBox="0 0 26 22" fill="none">
                                <path d="M15.8129 20.9813L25.4122 11.382C25.6081 11.1861 25.7181 10.9205 25.7181 10.6436C25.7181 10.3666 25.6081 10.101 25.4122 9.90515L15.8129 0.305849C15.6171 0.110011 15.3515 -1.03086e-05 15.0745 -1.0983e-05C14.7976 -1.014e-05 14.5319 0.11001 14.3361 0.305848C14.1403 0.501686 14.0303 0.7673 14.0303 1.04426C14.0303 1.32121 14.1403 1.58683 14.3361 1.78266L22.1531 9.59963L1.04478 9.59871C0.767665 9.59871 0.501903 9.70879 0.305957 9.90474C0.11001 10.1007 -7.1796e-05 10.3664 -7.17854e-05 10.6436C-7.1796e-05 10.9207 0.11001 11.1864 0.305957 11.3824C0.501903 11.5783 0.767665 11.6884 1.04478 11.6884L22.1531 11.6875L14.3361 19.5044C14.1403 19.7003 14.0303 19.9659 14.0303 20.2429C14.0303 20.5198 14.1403 20.7854 14.3361 20.9813C14.5319 21.1771 14.7976 21.2871 15.0745 21.2871C15.3515 21.2871 15.6171 21.1771 15.8129 20.9813Z" fill="#19060F"/>
                            </svg>
                        </span>
                    </div>
                </div>
            <?php endwhile; ?>
        <?php endif; ?>
    </div>
</section>

<?php get_footer(); ?>